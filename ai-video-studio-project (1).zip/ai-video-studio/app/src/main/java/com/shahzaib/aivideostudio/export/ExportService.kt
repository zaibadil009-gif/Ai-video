package com.shahzaib.aivideostudio.export

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.IBinder
import android.provider.MediaStore
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.shahzaib.aivideostudio.AiVideoStudioApp
import com.shahzaib.aivideostudio.audio.WavUtils
import com.shahzaib.aivideostudio.data.model.ExportResolution
import com.shahzaib.aivideostudio.render.PlaceholderArt
import com.shahzaib.aivideostudio.render.VideoRenderer
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Foreground service that renders the timeline into a finished MP4:
 * Ken Burns motion + burned-in subtitles + muxed AAC voiceover, then saves
 * to MediaStore (Movies/AIVideoStudio) and auto-captures a thumbnail.
 */
class ExportService : Service() {

    companion object {
        const val ACTION_EXPORT = "com.shahzaib.aivideostudio.action.EXPORT"
        const val EXTRA_PROJECT_ID = "project_id"
        private const val CHANNEL_ID = "export_channel"
        private const val NOTIF_ID = 1001

        fun start(context: Context, projectId: String) {
            val intent = Intent(context, ExportService::class.java).apply {
                action = ACTION_EXPORT
                putExtra(EXTRA_PROJECT_ID, projectId)
            }
            ContextCompat.startForegroundService(context, intent)
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action != ACTION_EXPORT) return START_NOT_STICKY
        val projectId = intent.getStringExtra(EXTRA_PROJECT_ID) ?: return START_NOT_STICKY

        createChannel()
        val notification = buildNotification(0f)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIF_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            )
        } else {
            startForeground(NOTIF_ID, notification)
        }

        ExportProgressBus.update(ExportProgressBus.State.Running(projectId, 0f))
        scope.launch { runExport(projectId) }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    private suspend fun runExport(projectId: String) {
        try {
            val app = application as AiVideoStudioApp
            val project = app.container.projects.load(projectId)
                ?: throw IllegalStateException("Project not found")
            val settings = app.container.settings.snapshot()

            val (w, h) = when (settings.exportResolution) {
                ExportResolution.P720 -> project.aspect.dims720p()
                ExportResolution.P1080 -> project.aspect.dims1080p()
            }
            val density = resources.displayMetrics.density

            val renderScenes = project.scenes.mapIndexed { index, s ->
                val decoded = s.imagePath?.let { BitmapFactory.decodeFile(it) }
                val base = decoded ?: PlaceholderArt.make(index, project.title, w, h)
                val bitmap = scaleToCover(base, w, h)
                if (bitmap !== base && !base.isRecycled) base.recycle()
                val pcm = s.voicePath?.let { path ->
                    try {
                        WavUtils.readWav(File(path))
                    } catch (_: Exception) {
                        null
                    }
                }
                VideoRenderer.RenderScene(
                    bitmap = bitmap,
                    pcm = pcm,
                    durationMs = s.durationMs,
                    motion = s.motion,
                    subtitle = s.narration.trim()
                )
            }

            val tmpOut = File(cacheDir, "export_${projectId}_${System.currentTimeMillis()}.mp4")
            val config = VideoRenderer.RenderConfig(
                width = w,
                height = h,
                videoBitrate = if (w >= 1080) 10_000_000 else 6_000_000,
                subtitlesEnabled = settings.subtitlesEnabled,
                subtitleSp = settings.subtitleSizeSp,
                subtitlePosition = settings.subtitlePosition,
                density = density,
                outputFile = tmpOut
            )

            var lastNotified = 0
            VideoRenderer().render(renderScenes, config) { p ->
                ExportProgressBus.update(ExportProgressBus.State.Running(projectId, p))
                val pct = (p * 100).toInt()
                if (pct - lastNotified >= 5) {
                    lastNotified = pct
                    updateNotification(p)
                }
            }
            renderScenes.forEach { if (!it.bitmap.isRecycled) it.bitmap.recycle() }

            ExportProgressBus.update(ExportProgressBus.State.Running(projectId, 0.97f))
            val videoPath = saveToMediaStore(tmpOut, sanitizeFileName(project.title) + ".mp4")
            tmpOut.delete()

            val thumbnailPath = captureThumbnail(videoPath, projectId)

            app.container.projects.updateOutput(projectId, videoPath, thumbnailPath)
            ExportProgressBus.update(
                ExportProgressBus.State.Done(projectId, videoPath, thumbnailPath)
            )
        } catch (e: Exception) {
            if (e is CancellationException) throw e
            ExportProgressBus.update(
                ExportProgressBus.State.Error(e.message ?: "Export failed")
            )
        } finally {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    // ------------------------------------------------------------------

    private fun scaleToCover(src: Bitmap, w: Int, h: Int): Bitmap {
        val scale = maxOf(w.toFloat() / src.width, h.toFloat() / src.height)
        if (scale <= 1f) return src // Ken Burns matrix upscales at draw time
        return Bitmap.createScaledBitmap(
            src, (src.width * scale).toInt(), (src.height * scale).toInt(), true
        )
    }

    private fun sanitizeFileName(name: String): String {
        val clean = name.replace(Regex("[\\\\/:*?\"<>|]"), "").trim().take(60)
        return clean.ifBlank { "ai_video" }.replace(' ', '_')
    }

    private suspend fun saveToMediaStore(src: File, displayName: String): String =
        withContext(Dispatchers.IO) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, displayName)
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/AIVideoStudio")
                    put(MediaStore.Video.Media.IS_PENDING, 1)
                }
                val resolver = contentResolver
                val uri = resolver.insert(
                    MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values
                ) ?: throw IllegalStateException("MediaStore insert failed")
                resolver.openOutputStream(uri)?.use { out ->
                    src.inputStream().use { it.copyTo(out) }
                } ?: throw IllegalStateException("Could not write video")
                values.clear()
                values.put(MediaStore.Video.Media.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
                uri.toString()
            } else {
                @Suppress("DEPRECATION")
                val movies = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES)
                val dir = File(movies, "AIVideoStudio").apply { mkdirs() }
                val dest = File(dir, displayName)
                src.copyTo(dest, overwrite = true)
                MediaScannerConnection.scanFile(
                    this@ExportService, arrayOf(dest.absolutePath), arrayOf("video/mp4"), null
                )
                dest.absolutePath
            }
        }

    /** Auto-captures the middle frame as a PNG thumbnail. */
    private fun captureThumbnail(videoPath: String, projectId: String): String? {
        return try {
            val retriever = MediaMetadataRetriever()
            if (videoPath.startsWith("content://")) {
                retriever.setDataSource(this, Uri.parse(videoPath))
            } else {
                retriever.setDataSource(videoPath)
            }
            val durMs = retriever.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_DURATION
            )?.toLongOrNull() ?: 0L
            val frame = retriever.getFrameAtTime(
                (durMs / 2) * 1000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC
            )
            retriever.release()
            if (frame != null) {
                val dir = File(filesDir, "thumbnails").apply { mkdirs() }
                val out = File(dir, "thumb_${projectId}_${System.currentTimeMillis()}.png")
                out.outputStream().use { frame.compress(Bitmap.CompressFormat.PNG, 100, it) }
                if (!frame.isRecycled) frame.recycle()
                out.absolutePath
            } else null
        } catch (_: Exception) {
            null
        }
    }

    // ------------------------------------------------------------------

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Video export", NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(progress: Float): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Rendering video")
            .setContentText("${(progress * 100).toInt()}% complete")
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setProgress(100, (progress * 100).toInt(), false)
            .setOngoing(true)
            .build()

    private fun updateNotification(progress: Float) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_ID, buildNotification(progress))
    }
}
