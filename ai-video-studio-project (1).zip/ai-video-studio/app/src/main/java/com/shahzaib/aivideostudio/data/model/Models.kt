package com.shahzaib.aivideostudio.data.model

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.util.UUID

/** Ken Burns style motion applied to a scene's image during export. */
enum class MotionType(val label: String) {
    ZOOM_IN("Zoom in"),
    ZOOM_OUT("Zoom out"),
    PAN_LEFT("Pan left"),
    PAN_RIGHT("Pan right"),
    STATIC("Static")
}

/** Export frame geometry. */
enum class AspectRatio(val label: String) {
    PORTRAIT("9:16"),
    LANDSCAPE("16:9");

    /** Returns (width, height) for the given quality tier. */
    fun dims1080p(): Pair<Int, Int> = when (this) {
        PORTRAIT -> 1080 to 1920
        LANDSCAPE -> 1920 to 1080
    }

    fun dims720p(): Pair<Int, Int> = when (this) {
        PORTRAIT -> 720 to 1280
        LANDSCAPE -> 1280 to 720
    }
}

enum class ExportResolution(val label: String) {
    P720("720p"),
    P1080("1080p")
}

enum class SubtitlePosition(val label: String) {
    TOP("Top"),
    BOTTOM("Bottom")
}

enum class TtsLocale(val label: String, val tag: String) {
    US("English (US)", "US"),
    UK("English (UK)", "UK")
}

/**
 * One editable scene in the timeline.
 * Properties are Compose-observable so timeline edits recompose instantly.
 */
class SceneDraft(
    val id: String = UUID.randomUUID().toString(),
    order: Int = 0,
    imagePrompt: String = "",
    narration: String = "",
    imagePath: String? = null,
    motion: MotionType = MotionType.ZOOM_IN,
    voicePath: String? = null,
    audioDurationMs: Long = 0L,
    minDurationMs: Long = 3000L,
    paddingMs: Long = 800L
) {
    var order by mutableStateOf(order)
    var imagePrompt by mutableStateOf(imagePrompt)
    var narration by mutableStateOf(narration)
    var imagePath by mutableStateOf(imagePath)
    var motion by mutableStateOf(motion)
    var voicePath by mutableStateOf(voicePath)
    var audioDurationMs by mutableStateOf(audioDurationMs)
    var minDurationMs by mutableStateOf(minDurationMs)
    var paddingMs by mutableStateOf(paddingMs)

    /** Final clip length: never shorter than minDuration, voice audio + padding otherwise. */
    val durationMs: Long
        get() = maxOf(minDurationMs, audioDurationMs + paddingMs)
}

data class ScriptDraft(
    val title: String,
    val scenes: List<SceneDraft>
)

data class SeoPackage(
    val title: String,
    val description: String,
    val tags: List<String>,
    val hashtags: List<String>
)

/** Full project used by the repository layer (draft + persistence fields). */
data class ProjectFull(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val topic: String,
    val aspect: AspectRatio,
    val resolution: ExportResolution,
    val scenes: List<SceneDraft>,
    val status: String = "draft",
    val videoPath: String? = null,
    val thumbnailPath: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
