package com.shahzaib.aivideostudio.export

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Shared export state observed by the UI while [ExportService] runs. */
object ExportProgressBus {

    sealed interface State {
        data object Idle : State
        data class Running(val projectId: String, val progress: Float) : State
        data class Done(
            val projectId: String,
            val videoPath: String,
            val thumbnailPath: String?
        ) : State
        data class Error(val message: String) : State
    }

    private val _state = MutableStateFlow<State>(State.Idle)
    val state: StateFlow<State> = _state.asStateFlow()

    fun update(state: State) {
        _state.value = state
    }

    fun reset() {
        _state.value = State.Idle
    }
}
