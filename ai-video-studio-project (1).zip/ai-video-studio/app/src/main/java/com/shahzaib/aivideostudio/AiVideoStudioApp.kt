package com.shahzaib.aivideostudio

import android.app.Application
import com.shahzaib.aivideostudio.data.db.AppDatabase
import com.shahzaib.aivideostudio.data.prefs.SettingsRepository
import com.shahzaib.aivideostudio.data.repo.ProjectRepository
import com.shahzaib.aivideostudio.network.LlmClient
import com.shahzaib.aivideostudio.network.PollinationsClient
import com.shahzaib.aivideostudio.script.ScriptEngine
import com.shahzaib.aivideostudio.seo.SeoGenerator
import com.shahzaib.aivideostudio.tts.TtsManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

class AiVideoStudioApp : Application() {

    val container: AppContainer by lazy { AppContainer(this) }

    override fun onTerminate() {
        // onTerminate is only called in emulators; real apps release in onTrimMemory etc.
        super.onTerminate()
    }
}

/** Manual dependency container (kept simple on purpose — no Hilt). */
class AppContainer(val app: AiVideoStudioApp) {

    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    val okHttp: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .build()

    val database: AppDatabase = AppDatabase.get(app)
    val settings = SettingsRepository(app)
    val projects = ProjectRepository(database)

    val pollinations = PollinationsClient(okHttp, app.filesDir)
    val llm = LlmClient(okHttp)
    val scriptEngine = ScriptEngine(llm, settings)
    val seoGenerator = SeoGenerator(llm, settings)
    val tts = TtsManager(app)
}
