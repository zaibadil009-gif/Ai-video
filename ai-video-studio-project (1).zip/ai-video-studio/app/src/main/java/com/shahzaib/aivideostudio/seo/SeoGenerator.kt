package com.shahzaib.aivideostudio.seo

import com.shahzaib.aivideostudio.data.model.SeoPackage
import com.shahzaib.aivideostudio.data.prefs.SettingsRepository
import com.shahzaib.aivideostudio.network.LlmClient
import org.json.JSONObject

/** Builds the upload SEO package: title, description, tags, hashtags. */
class SeoGenerator(
    private val llm: LlmClient,
    private val settings: SettingsRepository
) {
    suspend fun generate(topic: String, title: String): SeoPackage {
        val s = settings.snapshot()
        if (s.hasLlmKey) {
            try {
                val raw = llm.chat(
                    baseUrl = s.llmBaseUrl,
                    apiKey = s.llmApiKey,
                    model = s.llmModel,
                    system = "You are a YouTube SEO expert for English documentary, personal-finance " +
                        "and history channels. Reply with strict JSON only, no markdown. Schema: " +
                        "{\"title\": string (under 70 chars, click-worthy), " +
                        "\"description\": string (3 short paragraphs with a hook, what the video covers, " +
                        "and a call to action), \"tags\": [up to 12 strings], " +
                        "\"hashtags\": [5-8 strings starting with #]}.",
                    user = "Video topic: \"$topic\". Working title: \"$title\". Generate the SEO package."
                )
                return parse(llm.cleanJson(raw))
            } catch (_: Exception) {
                // fall through to template
            }
        }
        return template(topic, title)
    }

    private fun parse(json: String): SeoPackage {
        val root = JSONObject(json)
        return SeoPackage(
            title = root.optString("title", "Untitled"),
            description = root.optString("description", ""),
            tags = root.optJSONArray("tags")?.let { a ->
                (0 until a.length()).map { a.getString(it) }
            } ?: emptyList(),
            hashtags = root.optJSONArray("hashtags")?.let { a ->
                (0 until a.length()).map { a.getString(it) }
            } ?: emptyList()
        )
    }

    private fun template(topic: String, title: String): SeoPackage {
        val clean = topic.trim().trimEnd('.', '!', '?')
        val keywords = clean.split(Regex("[^A-Za-z0-9']+"))
            .filter { it.length > 3 }
            .distinct()
            .take(6)
        val tags = (listOf(clean) + keywords +
            listOf("documentary", "explained", "history", "personal finance", "story")).distinct().take(12)
        val hashtags = (keywords.map { "#" + it.replace("'", "") } +
            listOf("#Documentary", "#History", "#PersonalFinance")).distinct().take(8)
        val finalTitle = title.ifBlank { "$clean: The Untold Story" }.take(70)
        val description = """
            $finalTitle

            In this video, we break down $clean — the facts, the numbers, and the human story behind it, explained in simple English.

            CHAPTERS
            00:00 The hook
            Watch till the end for the one takeaway that changes how you see $clean.

            If you enjoy documentary-style storytelling, subscribe for a new deep dive every week.
        """.trimIndent()
        return SeoPackage(
            title = finalTitle,
            description = description,
            tags = tags,
            hashtags = hashtags
        )
    }
}
