package com.shahzaib.aivideostudio.data.db.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val title: String,
    val topic: String,
    /** "PORTRAIT" / "LANDSCAPE" */
    val aspect: String,
    /** "P720" / "P1080" */
    val resolution: String,
    /** draft | exported */
    val status: String = "draft",
    val videoPath: String? = null,
    val thumbnailPath: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "scenes",
    foreignKeys = [
        ForeignKey(
            entity = ProjectEntity::class,
            parentColumns = ["id"],
            childColumns = ["projectId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("projectId")]
)
data class SceneEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val projectId: String,
    val order: Int,
    val imagePrompt: String,
    val narration: String,
    val imagePath: String?,
    /** MotionType name */
    val motion: String,
    val voicePath: String?,
    val audioDurationMs: Long,
    val minDurationMs: Long,
    val paddingMs: Long
)
