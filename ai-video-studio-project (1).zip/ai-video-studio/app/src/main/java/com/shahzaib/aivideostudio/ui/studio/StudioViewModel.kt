package com.shahzaib.aivideostudio.ui.studio

import android.content.Context
import android.media.MediaPlayer
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shahzaib.aivideostudio.AppContainer
import com.shahzaib.aivideostudio.audio.WavUtils
import com.shahzaib.aivideostudio.data.model.AspectRatio
import com.shahzaib.aivideostudio.data.model.ExportResolution
import com.shahzaib.aivideostudio.data.model.ProjectFull
import com.shahzaib.aivideostudio.data.model.SceneDraft
import com.shahzaib.aivideostudio.data.model.SeoPackage
import com.shahzaib.aivideostudio.export.ExportService
import com.shahzaib.aivideostudio.share.ShareUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID
import kotlin.random.Random

/**
 * Orchestrates the whole studio flow for the project currently being edited:
 * script -> images -> voiceovers -> timeline -> export -> SEO.
 */
class StudioViewModel(private val c: AppContainer) : ViewModel() {

    var projectId: String? by mutableStateOf(null)
        private set
    var title by mutableStateOf("")
    var topic by mutableStateOf("")
    var inputText by mutableStateOf("")
    var inputIsScript by mutableStateOf(false)
    var aspect by mutableStateOf(AspectRatio.PORTRAIT)
    val scenes = mutableStateListOf<SceneDraft>()

    /** Non-null while a long job runs: shown as a blocking status line. */
    var busyMessage by mutableStateOf<String?>(null)
        private set
    var error by mutableStateOf<String?>(null)

    var seo by mutableStateOf<SeoPackage?>(null)
        private set
    var exportedVideoPath by mutableStateOf<String?>(null)
        private set
    var thumbnailPath by mutableStateOf<String?>(null)
        private set

    private var voicePlayer: MediaPlayer? = null

    fun resetForNew() {
        projectId = null
        title = ""
        topic = ""
        inputText = ""
        inputIsScript = false
        aspect = AspectRatio.PORTRAIT
        scenes.clear()
        seo = null
        exportedVideoPath = null
        thumbnailPath = null
        error = null
    }

    // ------------------------------------------------------------------
    // Script
    // ------------------------------------------------------------------

    fun generateScript(onDone: () -> Unit) {
        viewModelScope.launch {
            busyMessage = "Writing script…"
            error = null
            try {
                val draft = c.scriptEngine.generate(inputText, inputIsScript)
                title = draft.title
                topic = if (inputIsScript) "Custom script" else inputText.trim().take(80)
                scenes.clear()
                scenes.addAll(draft.scenes)
                reindex()
                onDone()
            } catch (e: Exception) {
                error = e.message ?: "Script generation failed"
            } finally {
                busyMessage = null
            }
        }
    }

    // ------------------------------------------------------------------
    // Images (Pollinations.ai — free, no key)
    // ------------------------------------------------------------------

    private fun imageDims(): Pair<Int, Int> = when (aspect) {
        AspectRatio.PORTRAIT -> 768 to 1344
        AspectRatio.LANDSCAPE -> 1344 to 768
    }

    fun generateAllImages() {
        viewModelScope.launch {
            error = null
            try {
                scenes.forEachIndexed { i, scene ->
                    busyMessage = "Generating image ${i + 1}/${scenes.size}…"
                    generateImageFor(scene)
                }
            } catch (e: Exception) {
                error = e.message ?: "Image generation failed"
            } finally {
                busyMessage = null
            }
        }
    }

    suspend fun generateImageFor(scene: SceneDraft) {
        val (w, h) = imageDims()
        val prompt = scene.imagePrompt.ifBlank { "Cinematic documentary film still" }
        val file = c.pollinations.generateImage(
            prompt = prompt,
            width = w,
            height = h,
            seed = Random.nextLong(1, 999_999),
            destName = "img_${scene.id}"
        )
        scene.imagePath = file.absolutePath
    }

    fun regenerateImage(scene: SceneDraft) {
        viewModelScope.launch {
            busyMessage = "Regenerating image…"
            error = null
            try {
                generateImageFor(scene)
            } catch (e: Exception) {
                error = e.message ?: "Image regeneration failed"
            } finally {
                busyMessage = null
            }
        }
    }

    /** Copies a gallery-picked image into the project's image slot. */
    suspend fun importGalleryImage(context: Context, scene: SceneDraft, uri: Uri) =
        withContext(Dispatchers.IO) {
            val dir = File(context.filesDir, "images").apply { mkdirs() }
            val dest = File(dir, "img_${scene.id}.jpg")
            context.contentResolver.openInputStream(uri)?.use { input ->
                dest.outputStream().use { output -> input.copyTo(output) }
            } ?: throw IllegalStateException("Could not read picked image")
            withContext(Dispatchers.Main) { scene.imagePath = dest.absolutePath }
        }

    // ------------------------------------------------------------------
    // Voiceover (on-device TTS — free)
    // ------------------------------------------------------------------

    fun generateAllVoiceovers() {
        viewModelScope.launch {
            error = null
            try {
                val s = c.settings.snapshot()
                if (!c.tts.ensureInit(s.ttsLocale)) {
                    throw IllegalStateException("On-device text-to-speech is unavailable")
                }
                scenes.forEachIndexed { i, scene ->
                    busyMessage = "Recording voiceover ${i + 1}/${scenes.size}…"
                    generateVoiceFor(scene, s.ttsLocale, s.ttsPitch, s.ttsRate, s.ttsVoiceName)
                }
            } catch (e: Exception) {
                error = e.message ?: "Voiceover generation failed"
            } finally {
                busyMessage = null
            }
        }
    }

    suspend fun generateVoiceFor(
        scene: SceneDraft,
        locale: com.shahzaib.aivideostudio.data.model.TtsLocale,
        pitch: Float,
        rate: Float,
        voiceName: String
    ) {
        val narration = scene.narration.trim()
        require(narration.isNotEmpty()) { "Scene narration is empty" }
        val dir = File(c.app.filesDir, "voice").apply { mkdirs() }
        val out = File(dir, "voice_${scene.id}.wav")
        c.tts.synthesizeToFile(narration, out, locale, pitch, rate, voiceName.ifBlank { null })
        scene.voicePath = out.absolutePath
        scene.audioDurationMs = WavUtils.durationMs(out)
    }

    fun regenerateVoice(scene: SceneDraft) {
        viewModelScope.launch {
            busyMessage = "Regenerating voiceover…"
            error = null
            try {
                val s = c.settings.snapshot()
                generateVoiceFor(scene, s.ttsLocale, s.ttsPitch, s.ttsRate, s.ttsVoiceName)
            } catch (e: Exception) {
                error = e.message ?: "Voiceover failed"
            } finally {
                busyMessage = null
            }
        }
    }

    /** Plays the scene's saved WAV voiceover. */
    fun previewVoice(scene: SceneDraft) {
        stopVoicePreview()
        val path = scene.voicePath
        if (path.isNullOrBlank()) {
            error = "Generate the voiceover first"
            return
        }
        try {
            voicePlayer = MediaPlayer().apply {
                setDataSource(path)
                prepare()
                start()
            }
        } catch (e: Exception) {
            error = e.message ?: "Could not play voiceover"
        }
    }

    fun stopVoicePreview() {
        try {
            voicePlayer?.stop()
            voicePlayer?.release()
        } catch (_: Exception) {
        }
        voicePlayer = null
    }

    // ------------------------------------------------------------------
    // Timeline editing
    // ------------------------------------------------------------------

    private fun reindex() {
        scenes.forEachIndexed { i, s -> s.order = i }
    }

    fun moveSceneUp(scene: SceneDraft) {
        val i = scenes.indexOf(scene)
        if (i > 0) {
            scenes.removeAt(i)
            scenes.add(i - 1, scene)
            reindex()
        }
    }

    fun moveSceneDown(scene: SceneDraft) {
        val i = scenes.indexOf(scene)
        if (i >= 0 && i < scenes.size - 1) {
            scenes.removeAt(i)
            scenes.add(i + 1, scene)
            reindex()
        }
    }

    fun deleteScene(scene: SceneDraft) {
        scenes.remove(scene)
        reindex()
    }

    fun addScene() {
        scenes.add(SceneDraft(order = scenes.size))
        reindex()
    }

    // ------------------------------------------------------------------
    // Persistence (Room)
    // ------------------------------------------------------------------

    suspend fun saveDraft(): String? {
        return try {
            val id = projectId ?: UUID.randomUUID().toString()
            val s = c.settings.snapshot()
            val full = ProjectFull(
                id = id,
                title = title.ifBlank { "Untitled Video" },
                topic = topic,
                aspect = aspect,
                resolution = s.exportResolution,
                scenes = scenes.toList(),
                status = if (exportedVideoPath != null) "exported" else "draft",
                videoPath = exportedVideoPath,
                thumbnailPath = thumbnailPath
            )
            c.projects.save(full)
            projectId = id
            id
        } catch (e: Exception) {
            error = e.message ?: "Save failed"
            null
        }
    }

    fun saveDraftAsync(onDone: (String?) -> Unit = {}) {
        viewModelScope.launch { onDone(saveDraft()) }
    }

    suspend fun loadProject(id: String): Boolean {
        return try {
            val full = c.projects.load(id) ?: return false
            projectId = full.id
            title = full.title
            topic = full.topic
            aspect = full.aspect
            scenes.clear()
            scenes.addAll(full.scenes)
            reindex()
            exportedVideoPath = full.videoPath
            thumbnailPath = full.thumbnailPath
            seo = null
            true
        } catch (e: Exception) {
            error = e.message ?: "Could not open project"
            false
        }
    }

    // ------------------------------------------------------------------
    // Export / thumbnail / SEO / voiceover-only
    // ------------------------------------------------------------------

    /** Saves the draft, then starts the foreground export service. */
    fun export(context: Context) {
        viewModelScope.launch {
            busyMessage = "Preparing export…"
            val id = saveDraft()
            busyMessage = null
            if (id != null) {
                ExportService.start(context, id)
            }
        }
    }

    /** Called by the UI when ExportService reports success. */
    fun onExportDone(videoPath: String, thumbnailPath: String?) {
        exportedVideoPath = videoPath
        if (thumbnailPath != null) this.thumbnailPath = thumbnailPath
        saveDraftAsync()
    }

    /** One-tap AI thumbnail from the video title (Pollinations). */
    fun makeAiThumbnail(onDone: (Boolean) -> Unit = {}) {
        viewModelScope.launch {
            busyMessage = "Creating AI thumbnail…"
            error = null
            try {
                val file = c.pollinations.generateImage(
                    prompt = "Viral YouTube thumbnail for a documentary video titled " +
                        "'${title.ifBlank { topic }}': bold cinematic composition, dramatic " +
                        "lighting, strong focal subject, high contrast, no text watermark",
                    width = 1280,
                    height = 720,
                    seed = Random.nextLong(1, 999_999),
                    destName = "thumb_ai_${System.currentTimeMillis()}"
                )
                thumbnailPath = file.absolutePath
                saveDraft()
                onDone(true)
            } catch (e: Exception) {
                error = e.message ?: "Thumbnail failed"
                onDone(false)
            } finally {
                busyMessage = null
            }
        }
    }

    /** Merges all scene voiceovers into one WAV and opens the share sheet. */
    fun exportVoiceoverOnly(context: Context) {
        viewModelScope.launch {
            busyMessage = "Merging voiceover…"
            error = null
            try {
                val files = scenes.mapNotNull { it.voicePath }.map { File(it) }.filter { it.exists() }
                if (files.isEmpty()) throw IllegalStateException("Generate voiceovers first")
                val dir = File(context.filesDir, "voiceover").apply { mkdirs() }
                val out = File(dir, "voiceover_${System.currentTimeMillis()}.wav")
                withContext(Dispatchers.IO) { WavUtils.concatWavs(files, out) }
                ShareUtils.shareFile(context, out, "audio/wav", "Share voiceover")
            } catch (e: Exception) {
                error = e.message ?: "Voiceover export failed"
            } finally {
                busyMessage = null
            }
        }
    }

    fun generateSeo() {
        viewModelScope.launch {
            busyMessage = "Writing SEO package…"
            error = null
            try {
                seo = c.seoGenerator.generate(topic, title)
            } catch (e: Exception) {
                error = e.message ?: "SEO generation failed"
            } finally {
                busyMessage = null
            }
        }
    }

    override fun onCleared() {
        stopVoicePreview()
        c.tts.stop()
        super.onCleared()
    }
}
