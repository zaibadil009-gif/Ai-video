package com.shahzaib.aivideostudio.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.shahzaib.aivideostudio.data.model.MotionType
import com.shahzaib.aivideostudio.data.model.SceneDraft
import com.shahzaib.aivideostudio.ui.components.ChipRow
import com.shahzaib.aivideostudio.ui.components.FullWidthButton
import com.shahzaib.aivideostudio.ui.components.LabeledSlider
import com.shahzaib.aivideostudio.ui.components.SectionTitle
import com.shahzaib.aivideostudio.ui.components.SpacerH
import com.shahzaib.aivideostudio.ui.components.StudioScaffold
import com.shahzaib.aivideostudio.ui.studio.StudioViewModel
import com.shahzaib.aivideostudio.util.TimeUtils
import kotlinx.coroutines.launch
import java.io.File

/** Step 3: CapCut-like timeline — reorder/trim clips, edit narration, images, voice. */
@Composable
fun TimelineScreen(
    vm: StudioViewModel,
    onBack: () -> Unit,
    onExport: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var selectedId by remember { mutableStateOf<String?>(null) }
    var galleryTarget by remember { mutableStateOf<SceneDraft?>(null) }

    val galleryLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        val target = galleryTarget
        if (uri != null && target != null) {
            scope.launch {
                try {
                    vm.importGalleryImage(context, target, uri)
                } catch (e: Exception) {
                    vm.error = e.message ?: "Import failed"
                }
            }
        }
        galleryTarget = null
    }

    val selected: SceneDraft? =
        vm.scenes.find { it.id == selectedId } ?: vm.scenes.firstOrNull()
    if (selected != null && selectedId == null) selectedId = selected.id

    StudioScaffold(
        title = "Timeline",
        onBack = onBack,
        actions = {
            IconButton(onClick = { vm.addScene() }) {
                Icon(Icons.Default.Add, contentDescription = "Add scene")
            }
            IconButton(onClick = { vm.saveDraftAsync() }) {
                Text("Save", style = MaterialTheme.typography.labelLarge)
            }
        },
        busyMessage = vm.busyMessage,
        error = vm.error,
        onErrorConsumed = { vm.error = null }
    ) { modifier ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(12.dp)
        ) {
            Text(
                "${vm.scenes.size} clips • total ${TimeUtils.formatMs(vm.scenes.sumOf { it.durationMs })}",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            SpacerH(8)

            // ---- Clip strip ----
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                itemsIndexed(vm.scenes, key = { _, s -> s.id }) { index, scene ->
                    ClipCard(
                        index = index,
                        scene = scene,
                        isSelected = scene.id == selected?.id,
                        onClick = { selectedId = scene.id }
                    )
                }
            }
            SpacerH(12)

            // ---- Selected clip editor ----
            if (selected != null) {
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val imgFile = selected.imagePath?.let { File(it) }
                    if (imgFile != null && imgFile.exists()) {
                        AsyncImage(
                            model = imgFile,
                            contentDescription = null,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(180.dp)
                                .clip(RoundedCornerShape(12.dp)),
                            contentScale = ContentScale.Crop
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = { vm.regenerateImage(selected) },
                            modifier = Modifier.weight(1f)
                        ) { Text("New image") }
                        OutlinedButton(
                            onClick = {
                                galleryTarget = selected
                                galleryLauncher.launch("image/*")
                            },
                            modifier = Modifier.weight(1f)
                        ) { Text("Gallery…") }
                    }
                    OutlinedTextField(
                        value = selected.narration,
                        onValueChange = { selected.narration = it },
                        label = { Text("Narration (English)") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 3
                    )
                    OutlinedTextField(
                        value = selected.imagePrompt,
                        onValueChange = { selected.imagePrompt = it },
                        label = { Text("Image prompt") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 2
                    )
                    SectionTitle("Motion")
                    ChipRow(
                        options = MotionType.values().map { it.label },
                        selected = selected.motion.label,
                        onSelect = { label ->
                            selected.motion = MotionType.values().first { it.label == label }
                        }
                    )
                    LabeledSlider(
                        label = "Minimum clip length",
                        value = selected.minDurationMs.toFloat(),
                        range = 2000f..10000f,
                        onChange = { selected.minDurationMs = it.toLong() },
                        format = { "${(it / 1000).toInt()}s" }
                    )
                    LabeledSlider(
                        label = "Pause after voice",
                        value = selected.paddingMs.toFloat(),
                        range = 0f..2500f,
                        onChange = { selected.paddingMs = it.toLong() },
                        format = { "${(it / 1000f)}s".take(4) + "s" }
                    )
                    Text(
                        "Clip length: ${TimeUtils.formatMs(selected.durationMs)}" +
                            (if (selected.audioDurationMs > 0)
                                " (voice ${TimeUtils.formatMs(selected.audioDurationMs)})"
                            else " (no voice yet)"),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = { vm.regenerateVoice(selected) },
                            modifier = Modifier.weight(1f)
                        ) { Text("New voice") }
                        OutlinedButton(
                            onClick = { vm.previewVoice(selected) },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null)
                            Spacer(Modifier.width(4.dp))
                            Text("Preview voice")
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { vm.moveSceneUp(selected) }) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Move earlier")
                        }
                        Text(
                            "Reorder clip",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        IconButton(onClick = { vm.moveSceneDown(selected) }) {
                            Icon(Icons.Default.ArrowForward, contentDescription = "Move later")
                        }
                        Spacer(Modifier.width(8.dp))
                        IconButton(onClick = {
                            vm.deleteScene(selected)
                            selectedId = null
                        }) {
                            Icon(
                                Icons.Default.Delete,
                                contentDescription = "Delete clip",
                                tint = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }
            } else {
                Text(
                    "Add a scene to begin.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.weight(1f)
                )
            }

            SpacerH(8)
            FullWidthButton(
                text = "Continue to export",
                enabled = vm.scenes.isNotEmpty() && vm.busyMessage == null,
                onClick = { vm.saveDraftAsync { onExport() } }
            )
        }
    }
}

@Composable
private fun ClipCard(
    index: Int,
    scene: SceneDraft,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val border = if (isSelected) {
        BorderStroke(2.dp, MaterialTheme.colorScheme.primary)
    } else null
    Card(
        modifier = Modifier
            .size(96.dp, 150.dp)
            .clickable(onClick = onClick),
        border = border,
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column {
            val imgFile = scene.imagePath?.let { File(it) }
            if (imgFile != null && imgFile.exists()) {
                AsyncImage(
                    model = imgFile,
                    contentDescription = null,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(96.dp),
                    contentScale = ContentScale.Crop
                )
            } else {
                androidx.compose.foundation.layout.Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(96.dp),
                    contentAlignment = Alignment.Center
                ) { Text("🖼") }
            }
            Column(Modifier.padding(6.dp)) {
                Text(
                    "Clip ${index + 1}",
                    style = MaterialTheme.typography.labelLarge,
                    maxLines = 1
                )
                Text(
                    TimeUtils.formatMs(scene.durationMs),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (scene.voicePath == null) {
                    Text(
                        "no voice",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.error
                    )
                }
            }
        }
    }
}
