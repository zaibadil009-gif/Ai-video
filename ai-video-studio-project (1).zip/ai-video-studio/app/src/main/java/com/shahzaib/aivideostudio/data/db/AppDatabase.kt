package com.shahzaib.aivideostudio.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.shahzaib.aivideostudio.data.db.entity.ProjectEntity
import com.shahzaib.aivideostudio.data.db.entity.SceneEntity

@Database(
    entities = [ProjectEntity::class, SceneEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun projectDao(): ProjectDao
    abstract fun sceneDao(): SceneDao

    companion object {
        @Volatile
        private var instance: AppDatabase? = null

        fun get(context: Context): AppDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "aivideostudio.db"
                ).build().also { instance = it }
            }
    }
}
