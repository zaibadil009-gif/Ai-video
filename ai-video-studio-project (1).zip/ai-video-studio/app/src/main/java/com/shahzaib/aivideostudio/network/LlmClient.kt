package com.shahzaib.aivideostudio.network

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException

/**
 * Minimal OpenAI-compatible chat client. Works with OpenAI, OpenRouter,
 * Together, Groq, LM Studio, Ollama, etc. — any base URL + key the user saves.
 */
class LlmClient(private val okHttp: OkHttpClient) {

    suspend fun chat(
        baseUrl: String,
        apiKey: String,
        model: String,
        system: String,
        user: String,
        temperature: Double = 0.7
    ): String = withContext(Dispatchers.IO) {
        val url = baseUrl.trimEnd('/') + "/chat/completions"
        val payload = JSONObject()
            .put("model", model)
            .put("temperature", temperature)
            .put(
                "messages", JSONArray()
                    .put(JSONObject().put("role", "system").put("content", system))
                    .put(JSONObject().put("role", "user").put("content", user))
            )
            .toString()

        val request = Request.Builder()
            .url(url)
            .addHeader("Authorization", "Bearer $apiKey")
            .addHeader("Content-Type", "application/json")
            .post(payload.toRequestBody("application/json".toMediaType()))
            .build()

        okHttp.newCall(request).execute().use { response ->
            val text = response.body?.string() ?: throw IOException("Empty LLM response")
            if (!response.isSuccessful) {
                throw IOException("LLM HTTP ${response.code}: ${text.take(300)}")
            }
            JSONObject(text)
                .getJSONArray("choices")
                .getJSONObject(0)
                .getJSONObject("message")
                .getString("content")
        }
    }

    /** Strips ```json fences if the model wrapped its answer. */
    fun cleanJson(raw: String): String {
        var s = raw.trim()
        if (s.startsWith("```")) {
            s = s.removePrefix("```json").removePrefix("```").trim()
            val end = s.lastIndexOf("```")
            if (end > 0) s = s.substring(0, end).trim()
        }
        return s
    }
}
