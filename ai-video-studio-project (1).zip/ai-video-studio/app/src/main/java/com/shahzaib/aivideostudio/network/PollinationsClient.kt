package com.shahzaib.aivideostudio.network

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.IOException
import java.net.URLEncoder

/**
 * Free AI image generation via Pollinations.ai — no API key required.
 * https://image.pollinations.ai/prompt/{prompt}?width=..&height=..&nologo=true&seed=..
 */
class PollinationsClient(
    private val okHttp: OkHttpClient,
    private val filesDir: File
) {
    suspend fun generateImage(
        prompt: String,
        width: Int,
        height: Int,
        seed: Long,
        destName: String
    ): File = withContext(Dispatchers.IO) {
        val encoded = URLEncoder.encode(prompt, "UTF-8")
        val url = "https://image.pollinations.ai/prompt/$encoded" +
            "?width=$width&height=$height&nologo=true&seed=$seed"
        val request = Request.Builder().url(url).get().build()
        okHttp.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw IOException("Pollinations HTTP ${response.code}")
            val body = response.body ?: throw IOException("Empty image response")
            val dir = File(filesDir, "images").apply { mkdirs() }
            val dest = File(dir, "$destName.jpg")
            body.byteStream().use { input ->
                dest.outputStream().use { output -> input.copyTo(output) }
            }
            if (dest.length() == 0L) throw IOException("Downloaded image is empty")
            dest
        }
    }
}
