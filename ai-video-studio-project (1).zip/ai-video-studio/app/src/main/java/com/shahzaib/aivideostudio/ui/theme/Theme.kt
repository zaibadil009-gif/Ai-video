package com.shahzaib.aivideostudio.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFF9D7BFF),
    onPrimary = Color(0xFF0B0B10),
    primaryContainer = Color(0xFF3D2B7A),
    onPrimaryContainer = Color(0xFFE8E2FF),
    secondary = Color(0xFF7FD8FF),
    onSecondary = Color(0xFF0B0B10),
    background = Color(0xFF0B0B10),
    onBackground = Color(0xFFF2F0FA),
    surface = Color(0xFF14141C),
    onSurface = Color(0xFFF2F0FA),
    surfaceVariant = Color(0xFF1E1E28),
    onSurfaceVariant = Color(0xFFB9B4CC),
    error = Color(0xFFFF8A80)
)

private val AppTypography = Typography(
    headlineSmall = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Bold,
        fontSize = 22.sp
    ),
    titleMedium = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.SemiBold,
        fontSize = 17.sp
    ),
    bodyMedium = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Normal,
        fontSize = 15.sp
    ),
    labelLarge = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Medium,
        fontSize = 14.sp
    )
)

/** App-wide dark Material3 theme. */
@Composable
fun AiVideoStudioTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = AppTypography,
        content = content
    )
}
