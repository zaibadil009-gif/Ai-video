package com.shahzaib.aivideostudio.render

/**
 * Converts ARGB_8888 pixels to NV12 (YUV420 semi-planar) which is what
 * [android.media.MediaCodec] encoders accept via ByteBuffer input
 * (COLOR_FormatYUV420SemiPlanar).
 *
 * NOTE: this is a straightforward CPU conversion. On mid-range phones it
 * encodes roughly 5-12 fps at 720p; export runs in a foreground service so
 * the app can be backgrounded while it works.
 */
object YuvConverter {

    fun argbToNv12(argb: IntArray, width: Int, height: Int, out: ByteArray) {
        require(out.size >= width * height * 3 / 2)
        val frameSize = width * height
        var yIndex = 0
        var uvIndex = frameSize

        var index = 0
        for (j in 0 until height) {
            for (i in 0 until width) {
                val pixel = argb[index++]
                val r = (pixel shr 16) and 0xFF
                val g = (pixel shr 8) and 0xFF
                val b = pixel and 0xFF

                var y = ((66 * r + 129 * g + 25 * b + 128) shr 8) + 16
                if (y < 16) y = 16 else if (y > 255) y = 255
                out[yIndex++] = y.toByte()

                // Subsampled chroma: write VU pair once per 2x2 block
                if (j % 2 == 0 && i % 2 == 0) {
                    // Average the 2x2 block for smoother chroma
                    var rSum = r
                    var gSum = g
                    var bSum = b
                    var count = 1
                    if (i + 1 < width) {
                        val p2 = argb[index]
                        rSum += (p2 shr 16) and 0xFF
                        gSum += (p2 shr 8) and 0xFF
                        bSum += p2 and 0xFF
                        count++
                    }
                    if (j + 1 < height) {
                        val p3 = argb[index + width - 1]
                        rSum += (p3 shr 16) and 0xFF
                        gSum += (p3 shr 8) and 0xFF
                        bSum += p3 and 0xFF
                        count++
                        if (i + 1 < width) {
                            val p4 = argb[index + width]
                            rSum += (p4 shr 16) and 0xFF
                            gSum += (p4 shr 8) and 0xFF
                            bSum += p4 and 0xFF
                            count++
                        }
                    }
                    val ra = rSum / count
                    val ga = gSum / count
                    val ba = bSum / count
                    var u = ((-38 * ra - 74 * ga + 112 * ba + 128) shr 8) + 128
                    var v = ((112 * ra - 94 * ga - 18 * ba + 128) shr 8) + 128
                    if (u < 0) u = 0 else if (u > 255) u = 255
                    if (v < 0) v = 0 else if (v > 255) v = 255
                    out[uvIndex++] = v.toByte() // NV12 = Y + interleaved VU
                    out[uvIndex++] = u.toByte()
                }
            }
        }
    }
}
