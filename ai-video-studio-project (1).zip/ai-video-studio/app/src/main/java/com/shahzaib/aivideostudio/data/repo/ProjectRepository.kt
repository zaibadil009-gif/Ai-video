package com.shahzaib.aivideostudio.data.repo

import com.shahzaib.aivideostudio.data.db.AppDatabase
import com.shahzaib.aivideostudio.data.db.entity.ProjectEntity
import com.shahzaib.aivideostudio.data.db.entity.SceneEntity
import com.shahzaib.aivideostudio.data.model.AspectRatio
import com.shahzaib.aivideostudio.data.model.ExportResolution
import com.shahzaib.aivideostudio.data.model.MotionType
import com.shahzaib.aivideostudio.data.model.ProjectFull
import com.shahzaib.aivideostudio.data.model.SceneDraft
import kotlinx.coroutines.flow.Flow

/** Maps between Room entities and the in-memory draft model. */
class ProjectRepository(private val db: AppDatabase) {

    fun observeAll(): Flow<List<ProjectEntity>> = db.projectDao().observeAll()

    suspend fun save(full: ProjectFull): String {
        val now = System.currentTimeMillis()
        db.projectDao().upsert(
            ProjectEntity(
                id = full.id,
                title = full.title,
                topic = full.topic,
                aspect = full.aspect.name,
                resolution = full.resolution.name,
                status = full.status,
                videoPath = full.videoPath,
                thumbnailPath = full.thumbnailPath,
                createdAt = full.createdAt,
                updatedAt = now
            )
        )
        db.sceneDao().deleteForProject(full.id)
        db.sceneDao().upsertAll(
            full.scenes.mapIndexed { index, s ->
                SceneEntity(
                    id = s.id,
                    projectId = full.id,
                    order = index,
                    imagePrompt = s.imagePrompt,
                    narration = s.narration,
                    imagePath = s.imagePath,
                    motion = s.motion.name,
                    voicePath = s.voicePath,
                    audioDurationMs = s.audioDurationMs,
                    minDurationMs = s.minDurationMs,
                    paddingMs = s.paddingMs
                )
            }
        )
        return full.id
    }

    suspend fun load(id: String): ProjectFull? {
        val p = db.projectDao().getById(id) ?: return null
        val scenes = db.sceneDao().getForProject(id).map { e ->
            SceneDraft(
                id = e.id,
                order = e.order,
                imagePrompt = e.imagePrompt,
                narration = e.narration,
                imagePath = e.imagePath,
                motion = runCatching { MotionType.valueOf(e.motion) }.getOrDefault(MotionType.ZOOM_IN),
                voicePath = e.voicePath,
                audioDurationMs = e.audioDurationMs,
                minDurationMs = e.minDurationMs,
                paddingMs = e.paddingMs
            )
        }
        return ProjectFull(
            id = p.id,
            title = p.title,
            topic = p.topic,
            aspect = runCatching { AspectRatio.valueOf(p.aspect) }.getOrDefault(AspectRatio.PORTRAIT),
            resolution = runCatching { ExportResolution.valueOf(p.resolution) }.getOrDefault(ExportResolution.P720),
            scenes = scenes,
            status = p.status,
            videoPath = p.videoPath,
            thumbnailPath = p.thumbnailPath,
            createdAt = p.createdAt,
            updatedAt = p.updatedAt
        )
    }

    suspend fun updateOutput(id: String, videoPath: String, thumbnailPath: String?) {
        val p = db.projectDao().getById(id) ?: return
        db.projectDao().upsert(
            p.copy(
                status = "exported",
                videoPath = videoPath,
                thumbnailPath = thumbnailPath,
                updatedAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun delete(id: String) {
        db.sceneDao().deleteForProject(id)
        db.projectDao().delete(id)
    }
}
