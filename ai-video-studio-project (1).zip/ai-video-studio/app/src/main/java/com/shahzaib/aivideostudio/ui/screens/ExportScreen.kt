package com.shahzaib.aivideostudio.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.shahzaib.aivideostudio.data.model.SubtitlePosition
import com.shahzaib.aivideostudio.export.ExportProgressBus
import com.shahzaib.aivideostudio.share.ShareUtils
import com.shahzaib.aivideostudio.ui.components.ChipRow
import com.shahzaib.aivideostudio.ui.components.FullWidthButton
import com.shahzaib.aivideostudio.ui.components.LabeledSlider
import com.shahzaib.aivideostudio.ui.components.ProgressRow
import com.shahzaib.aivideostudio.ui.components.SectionTitle
import com.shahzaib.aivideostudio.ui.components.SpacerH
import com.shahzaib.aivideostudio.ui.components.StudioScaffold
import com.shahzaib.aivideostudio.ui.studio.SettingsViewModel
import com.shahzaib.aivideostudio.ui.studio.StudioViewModel
import com.shahzaib.aivideostudio.util.TimeUtils
import java.io.File

/** Step 4: export settings, progress, finished video, thumbnail, next steps. */
@Composable
fun ExportScreen(
    vm: StudioViewModel,
    settingsVm: SettingsViewModel,
    onBack: () -> Unit,
    onSeo: () -> Unit
) {
    val context = LocalContext.current
    val exportState by ExportProgressBus.state.collectAsState()
    val settings by settingsVm.settings.collectAsState()
    var doneHandledFor by remember { mutableStateOf<String?>(null) }

    val notifLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { vm.export(context) }

    fun doExport() {
        val needsPermission = Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(
                context, Manifest.permission.POST_NOTIFICATIONS
            ) != PackageManager.PERMISSION_GRANTED
        if (needsPermission) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        else vm.export(context)
    }

    // Sync the finished export back into the in-memory draft (for SEO screen etc.)
    LaunchedEffect(exportState) {
        val s = exportState
        if (s is ExportProgressBus.State.Done && doneHandledFor != s.videoPath) {
            doneHandledFor = s.videoPath
            vm.onExportDone(s.videoPath, s.thumbnailPath)
        }
    }

    StudioScaffold(
        title = "Export video",
        onBack = onBack,
        busyMessage = vm.busyMessage,
        error = vm.error,
        onErrorConsumed = { vm.error = null }
    ) { modifier ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                "${vm.scenes.size} clips • about ${TimeUtils.formatMs(vm.scenes.sumOf { it.durationMs })} • " +
                    "${settings.exportResolution.label} ${settings.aspect.label}",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            SectionTitle("Subtitles")
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Burn subtitles into video", style = MaterialTheme.typography.bodyMedium)
                Switch(
                    checked = settings.subtitlesEnabled,
                    onCheckedChange = {
                        settingsVm.saveSubtitles(it, settings.subtitleSizeSp, settings.subtitlePosition)
                    }
                )
            }
            if (settings.subtitlesEnabled) {
                LabeledSlider(
                    label = "Subtitle size",
                    value = settings.subtitleSizeSp,
                    range = 14f..36f,
                    onChange = {
                        settingsVm.saveSubtitles(true, it, settings.subtitlePosition)
                    },
                    format = { "${it.toInt()}sp" }
                )
                ChipRow(
                    options = SubtitlePosition.values().map { it.label },
                    selected = settings.subtitlePosition.label,
                    onSelect = { label ->
                        settingsVm.saveSubtitles(
                            true,
                            settings.subtitleSizeSp,
                            SubtitlePosition.values().first { it.label == label }
                        )
                    }
                )
            }

            SpacerH(4)
            when (val s = exportState) {
                is ExportProgressBus.State.Running -> {
                    ProgressRow("Rendering video…", s.progress)
                    Text(
                        "You can leave the app — rendering continues in the background.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                is ExportProgressBus.State.Error -> {
                    Text(
                        "Export failed: ${s.message}",
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodyMedium
                    )
                    FullWidthButton(text = "Try again", onClick = { doExport() })
                }
                is ExportProgressBus.State.Done -> {
                    DonePanel(
                        videoPath = s.videoPath,
                        thumbnailPath = s.thumbnailPath,
                        onAiThumbnail = { vm.makeAiThumbnail() },
                        onShare = {
                            if (s.videoPath.startsWith("content://")) {
                                ShareUtils.shareContentUri(
                                    context, Uri.parse(s.videoPath), "video/mp4", "Share video"
                                )
                            } else {
                                ShareUtils.shareFile(
                                    context, File(s.videoPath), "video/mp4", "Share video"
                                )
                            }
                        },
                        onSeo = onSeo
                    )
                }
                ExportProgressBus.State.Idle -> {
                    FullWidthButton(
                        text = "Render & export MP4",
                        enabled = vm.scenes.isNotEmpty() && vm.busyMessage == null,
                        onClick = { doExport() }
                    )
                    Text(
                        "Saved to Movies/AIVideoStudio on your phone. " +
                            "A thumbnail is captured automatically when rendering finishes.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun DonePanel(
    videoPath: String,
    thumbnailPath: String?,
    onAiThumbnail: () -> Unit,
    onShare: () -> Unit,
    onSeo: () -> Unit
) {
    Text("Video ready ✓", style = MaterialTheme.typography.headlineSmall)
    SpacerH(4)

    // In-app preview with ExoPlayer (preview only — export itself is MediaCodec).
    VideoPreviewPlayer(
        videoPath = videoPath,
        modifier = Modifier
            .fillMaxWidth()
            .height(220.dp)
            .clip(RoundedCornerShape(12.dp))
    )
    SpacerH(4)

    val thumbFile = thumbnailPath?.let { File(it) }
    if (thumbFile != null && thumbFile.exists()) {
        Text("Auto-captured thumbnail:", style = MaterialTheme.typography.labelLarge)
        AsyncImage(
            model = thumbFile,
            contentDescription = "Video thumbnail",
            modifier = Modifier
                .fillMaxWidth()
                .height(160.dp)
                .clip(RoundedCornerShape(12.dp)),
            contentScale = ContentScale.Crop
        )
        SpacerH(4)
    }

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        OutlinedButton(onClick = onAiThumbnail, modifier = Modifier.weight(1f)) {
            Text("AI thumbnail")
        }
        OutlinedButton(onClick = onShare, modifier = Modifier.weight(1f)) {
            Text("Share video")
        }
    }
    SpacerH(4)
    FullWidthButton(text = "Continue to SEO package", onClick = onSeo)
}

/** ExoPlayer is used ONLY for preview playback inside the app. */
@Composable
private fun VideoPreviewPlayer(videoPath: String, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val player = remember(videoPath) {
        ExoPlayer.Builder(context).build().apply {
            val uri = if (videoPath.startsWith("content://")) Uri.parse(videoPath)
            else Uri.fromFile(File(videoPath))
            setMediaItem(MediaItem.fromUri(uri))
            prepare()
        }
    }
    DisposableEffect(Unit) {
        onDispose { player.release() }
    }
    AndroidView(
        factory = { ctx ->
            PlayerView(ctx).apply {
                this.player = player
                useController = true
            }
        },
        modifier = modifier
    )
}
