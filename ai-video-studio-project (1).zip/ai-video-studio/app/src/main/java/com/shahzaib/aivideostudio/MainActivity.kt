package com.shahzaib.aivideostudio

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import com.shahzaib.aivideostudio.ui.nav.NavGraph
import com.shahzaib.aivideostudio.ui.studio.HomeViewModel
import com.shahzaib.aivideostudio.ui.studio.SettingsViewModel
import com.shahzaib.aivideostudio.ui.studio.StudioViewModel
import com.shahzaib.aivideostudio.ui.studio.StudioVmFactory
import com.shahzaib.aivideostudio.ui.theme.AiVideoStudioTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = application as AiVideoStudioApp
        val factory = StudioVmFactory(app.container)

        val studioVm: StudioViewModel by viewModels { factory }
        val homeVm: HomeViewModel by viewModels { factory }
        val settingsVm: SettingsViewModel by viewModels { factory }

        setContent {
            AiVideoStudioTheme {
                NavGraph(
                    studioVm = studioVm,
                    homeVm = homeVm,
                    settingsVm = settingsVm
                )
            }
        }
    }
}
