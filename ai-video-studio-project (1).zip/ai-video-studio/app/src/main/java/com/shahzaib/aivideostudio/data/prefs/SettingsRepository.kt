package com.shahzaib.aivideostudio.data.prefs

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.shahzaib.aivideostudio.data.model.AspectRatio
import com.shahzaib.aivideostudio.data.model.ExportResolution
import com.shahzaib.aivideostudio.data.model.SubtitlePosition
import com.shahzaib.aivideostudio.data.model.TtsLocale
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "ai_video_studio_settings")

/** All user settings, persisted with DataStore Preferences. */
data class Settings(
    val llmBaseUrl: String = "",
    val llmApiKey: String = "",
    val llmModel: String = "gpt-4o-mini",
    val ttsLocale: TtsLocale = TtsLocale.US,
    val ttsPitch: Float = 1.0f,
    val ttsRate: Float = 1.0f,
    val ttsVoiceName: String = "",
    val exportResolution: ExportResolution = ExportResolution.P720,
    val aspect: AspectRatio = AspectRatio.PORTRAIT,
    val subtitlesEnabled: Boolean = true,
    val subtitleSizeSp: Float = 22f,
    val subtitlePosition: SubtitlePosition = SubtitlePosition.BOTTOM
) {
    val hasLlmKey: Boolean get() = llmBaseUrl.isNotBlank() && llmApiKey.isNotBlank()
}

class SettingsRepository(private val context: Context) {

    private object Keys {
        val LLM_BASE_URL = stringPreferencesKey("llm_base_url")
        val LLM_API_KEY = stringPreferencesKey("llm_api_key")
        val LLM_MODEL = stringPreferencesKey("llm_model")
        val TTS_LOCALE = stringPreferencesKey("tts_locale")
        val TTS_PITCH = floatPreferencesKey("tts_pitch")
        val TTS_RATE = floatPreferencesKey("tts_rate")
        val TTS_VOICE = stringPreferencesKey("tts_voice")
        val EXPORT_RES = stringPreferencesKey("export_resolution")
        val ASPECT = stringPreferencesKey("aspect")
        val SUB_ENABLED = booleanPreferencesKey("subtitles_enabled")
        val SUB_SIZE = floatPreferencesKey("subtitle_size_sp")
        val SUB_POS = stringPreferencesKey("subtitle_position")
    }

    val settings: Flow<Settings> = context.dataStore.data.map { p ->
        Settings(
            llmBaseUrl = p[Keys.LLM_BASE_URL].orEmpty(),
            llmApiKey = p[Keys.LLM_API_KEY].orEmpty(),
            llmModel = p[Keys.LLM_MODEL] ?: "gpt-4o-mini",
            ttsLocale = runCatching { TtsLocale.valueOf(p[Keys.TTS_LOCALE] ?: "US") }.getOrDefault(TtsLocale.US),
            ttsPitch = p[Keys.TTS_PITCH] ?: 1.0f,
            ttsRate = p[Keys.TTS_RATE] ?: 1.0f,
            ttsVoiceName = p[Keys.TTS_VOICE].orEmpty(),
            exportResolution = runCatching { ExportResolution.valueOf(p[Keys.EXPORT_RES] ?: "P720") }.getOrDefault(ExportResolution.P720),
            aspect = runCatching { AspectRatio.valueOf(p[Keys.ASPECT] ?: "PORTRAIT") }.getOrDefault(AspectRatio.PORTRAIT),
            subtitlesEnabled = p[Keys.SUB_ENABLED] ?: true,
            subtitleSizeSp = p[Keys.SUB_SIZE] ?: 22f,
            subtitlePosition = runCatching { SubtitlePosition.valueOf(p[Keys.SUB_POS] ?: "BOTTOM") }.getOrDefault(SubtitlePosition.BOTTOM)
        )
    }

    suspend fun snapshot(): Settings = settings.first()

    suspend fun setLlm(baseUrl: String, apiKey: String, model: String) {
        context.dataStore.edit {
            it[Keys.LLM_BASE_URL] = baseUrl.trim()
            it[Keys.LLM_API_KEY] = apiKey.trim()
            it[Keys.LLM_MODEL] = model.trim().ifBlank { "gpt-4o-mini" }
        }
    }

    suspend fun setTts(locale: TtsLocale, pitch: Float, rate: Float, voiceName: String) {
        context.dataStore.edit {
            it[Keys.TTS_LOCALE] = locale.name
            it[Keys.TTS_PITCH] = pitch
            it[Keys.TTS_RATE] = rate
            it[Keys.TTS_VOICE] = voiceName
        }
    }

    suspend fun setExport(resolution: ExportResolution, aspect: AspectRatio) {
        context.dataStore.edit {
            it[Keys.EXPORT_RES] = resolution.name
            it[Keys.ASPECT] = aspect.name
        }
    }

    suspend fun setSubtitles(enabled: Boolean, sizeSp: Float, position: SubtitlePosition) {
        context.dataStore.edit {
            it[Keys.SUB_ENABLED] = enabled
            it[Keys.SUB_SIZE] = sizeSp
            it[Keys.SUB_POS] = position.name
        }
    }
}
