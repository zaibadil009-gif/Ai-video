package com.shahzaib.aivideostudio.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.shahzaib.aivideostudio.data.model.AspectRatio
import com.shahzaib.aivideostudio.ui.components.ChipRow
import com.shahzaib.aivideostudio.ui.components.FullWidthButton
import com.shahzaib.aivideostudio.ui.components.SectionTitle
import com.shahzaib.aivideostudio.ui.components.SpacerH
import com.shahzaib.aivideostudio.ui.components.StudioScaffold
import com.shahzaib.aivideostudio.ui.studio.StudioViewModel

/** Step 1: topic or pasted script + aspect ratio. */
@Composable
fun NewProjectScreen(
    vm: StudioViewModel,
    onBack: () -> Unit,
    onScriptReady: () -> Unit
) {
    StudioScaffold(
        title = "New video",
        onBack = onBack,
        busyMessage = vm.busyMessage,
        error = vm.error,
        onErrorConsumed = { vm.error = null }
    ) { modifier ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                "Type a topic and AI writes the script — or paste your own full script.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            OutlinedTextField(
                value = vm.inputText,
                onValueChange = { vm.inputText = it },
                label = { Text(if (vm.inputIsScript) "Paste your script" else "Video topic") },
                placeholder = {
                    Text(
                        if (vm.inputIsScript) "Paste the full English narration here…"
                        else "e.g. The rise and fall of the Ottoman Empire"
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp),
                minLines = 5
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("I already have a full script", style = MaterialTheme.typography.bodyMedium)
                Switch(
                    checked = vm.inputIsScript,
                    onCheckedChange = { vm.inputIsScript = it }
                )
            }
            SectionTitle("Video shape")
            ChipRow(
                options = AspectRatio.values().map { it.label },
                selected = vm.aspect.label,
                onSelect = { label ->
                    vm.aspect = AspectRatio.values().first { it.label == label }
                }
            )
            Text(
                "Tip: use 9:16 for Shorts/Reels/TikTok, 16:9 for YouTube.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            SpacerH(8)
            FullWidthButton(
                text = "Write script & build scenes",
                enabled = vm.inputText.isNotBlank() && vm.busyMessage == null,
                onClick = { vm.generateScript(onScriptReady) }
            )
            Spacer(Modifier.height(4.dp))
            Text(
                "Uses your own AI key if you saved one in Settings, otherwise the built-in writer.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
