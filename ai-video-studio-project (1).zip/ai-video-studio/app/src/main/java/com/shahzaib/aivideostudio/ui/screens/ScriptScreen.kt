package com.shahzaib.aivideostudio.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.shahzaib.aivideostudio.ui.components.FullWidthButton
import com.shahzaib.aivideostudio.ui.components.SectionTitle
import com.shahzaib.aivideostudio.ui.components.SpacerH
import com.shahzaib.aivideostudio.ui.components.StudioScaffold
import com.shahzaib.aivideostudio.ui.studio.StudioViewModel
import com.shahzaib.aivideostudio.util.TimeUtils

/** Step 2: review/edit the script, generate images + voiceovers. */
@Composable
fun ScriptScreen(
    vm: StudioViewModel,
    onBack: () -> Unit,
    onContinue: () -> Unit
) {
    StudioScaffold(
        title = "Script & scenes",
        onBack = onBack,
        busyMessage = vm.busyMessage,
        error = vm.error,
        onErrorConsumed = { vm.error = null }
    ) { modifier ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            OutlinedTextField(
                value = vm.title,
                onValueChange = { vm.title = it },
                label = { Text("Video title") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            SpacerH(8)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = { vm.generateAllImages() },
                    enabled = vm.busyMessage == null,
                    modifier = Modifier.weight(1f)
                ) { Text("Generate images") }
                OutlinedButton(
                    onClick = { vm.generateAllVoiceovers() },
                    enabled = vm.busyMessage == null,
                    modifier = Modifier.weight(1f)
                ) { Text("Generate voice") }
            }
            SpacerH(4)
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                itemsIndexed(vm.scenes, key = { _, s -> s.id }) { index, scene ->
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant
                        )
                    ) {
                        Column(Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                SectionTitle("Scene ${index + 1}")
                                Row {
                                    IconButton(onClick = { vm.regenerateImage(scene) }) {
                                        Icon(Icons.Default.Refresh, contentDescription = "Regenerate image")
                                    }
                                    IconButton(onClick = { vm.regenerateVoice(scene) }) {
                                        Text("🎙", style = MaterialTheme.typography.titleMedium)
                                    }
                                }
                            }
                            OutlinedTextField(
                                value = scene.narration,
                                onValueChange = { scene.narration = it },
                                label = { Text("Narration (English)") },
                                modifier = Modifier.fillMaxWidth(),
                                minLines = 2
                            )
                            Spacer(Modifier.height(8.dp))
                            OutlinedTextField(
                                value = scene.imagePrompt,
                                onValueChange = { scene.imagePrompt = it },
                                label = { Text("Image prompt") },
                                modifier = Modifier.fillMaxWidth(),
                                minLines = 2
                            )
                            Spacer(Modifier.height(4.dp))
                            val img = if (scene.imagePath != null) "✓ Image ready" else "○ No image yet"
                            val voice = if (scene.voicePath != null) {
                                "✓ Voice ready (${TimeUtils.formatMs(scene.audioDurationMs)})"
                            } else "○ No voice yet"
                            Text(
                                "$img   •   $voice",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
            SpacerH(8)
            FullWidthButton(
                text = "Save & open timeline",
                enabled = vm.scenes.isNotEmpty() && vm.busyMessage == null,
                onClick = { vm.saveDraftAsync { onContinue() } }
            )
        }
    }
}
