package com.shahzaib.aivideostudio.ui.studio

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.shahzaib.aivideostudio.AppContainer
import com.shahzaib.aivideostudio.data.db.entity.ProjectEntity
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class HomeViewModel(private val c: AppContainer) : ViewModel() {

    val projects: StateFlow<List<ProjectEntity>> =
        c.projects.observeAll()
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun deleteProject(id: String) {
        viewModelScope.launch { c.projects.delete(id) }
    }
}

class SettingsViewModel(private val c: AppContainer) : ViewModel() {

    val settings = c.settings.settings
        .stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5_000),
            com.shahzaib.aivideostudio.data.prefs.Settings()
        )

    fun saveLlm(baseUrl: String, apiKey: String, model: String) {
        viewModelScope.launch { c.settings.setLlm(baseUrl, apiKey, model) }
    }

    fun saveTts(
        locale: com.shahzaib.aivideostudio.data.model.TtsLocale,
        pitch: Float,
        rate: Float,
        voiceName: String
    ) {
        viewModelScope.launch { c.settings.setTts(locale, pitch, rate, voiceName) }
    }

    fun saveExport(
        resolution: com.shahzaib.aivideostudio.data.model.ExportResolution,
        aspect: com.shahzaib.aivideostudio.data.model.AspectRatio
    ) {
        viewModelScope.launch { c.settings.setExport(resolution, aspect) }
    }

    fun saveSubtitles(
        enabled: Boolean,
        sizeSp: Float,
        position: com.shahzaib.aivideostudio.data.model.SubtitlePosition
    ) {
        viewModelScope.launch { c.settings.setSubtitles(enabled, sizeSp, position) }
    }

    /** Refreshes the list of on-device English TTS voices. */
    fun refreshVoices(onDone: (List<android.speech.tts.Voice>) -> Unit) {
        viewModelScope.launch {
            val s = c.settings.snapshot()
            c.tts.ensureInit(s.ttsLocale)
            onDone(c.tts.englishVoices())
        }
    }
}

/** Simple factory wiring the manual DI container into ViewModels. */
class StudioVmFactory(private val c: AppContainer) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = when {
        modelClass.isAssignableFrom(StudioViewModel::class.java) -> StudioViewModel(c)
        modelClass.isAssignableFrom(HomeViewModel::class.java) -> HomeViewModel(c)
        modelClass.isAssignableFrom(SettingsViewModel::class.java) -> SettingsViewModel(c)
        else -> throw IllegalArgumentException("Unknown ViewModel ${modelClass.name}")
    } as T
}
