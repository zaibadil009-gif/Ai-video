package com.shahzaib.aivideostudio.render

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import com.shahzaib.aivideostudio.audio.PcmAudio
import com.shahzaib.aivideostudio.data.model.MotionType
import com.shahzaib.aivideostudio.data.model.SubtitlePosition
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteBuffer

/**
 * Manual H.264 (AVC) + AAC export pipeline built directly on
 * [MediaCodec] and [MediaMuxer] — no high-level transformer involved.
 *
 * For every scene it renders frames at [RenderConfig.fps], drawing the scene
 * bitmap through a time-based Ken Burns transform and burning the scene's
 * subtitle cue into the pixels. Each scene's WAV voiceover is transcoded to
 * AAC and muxed with continuous presentation timestamps across scenes.
 *
 * Output: a single .mp4 file.
 */
class VideoRenderer {

    data class RenderScene(
        val bitmap: Bitmap,
        val pcm: PcmAudio?,
        val durationMs: Long,
        val motion: MotionType,
        val subtitle: String?
    )

    data class RenderConfig(
        val width: Int,
        val height: Int,
        val fps: Int = 30,
        val videoBitrate: Int = 6_000_000,
        val audioBitrate: Int = 128_000,
        val subtitlesEnabled: Boolean = true,
        val subtitleSp: Float = 22f,
        val subtitlePosition: SubtitlePosition = SubtitlePosition.BOTTOM,
        /** Display density used to convert subtitle sp -> px. */
        val density: Float = 2f,
        val outputFile: File
    )

    suspend fun render(
        scenes: List<RenderScene>,
        config: RenderConfig,
        onProgress: (Float) -> Unit = {}
    ) = withContext(Dispatchers.Default) {
        require(scenes.isNotEmpty()) { "No scenes to render" }
        config.outputFile.parentFile?.mkdirs()

        val hasAudio = scenes.any { it.pcm != null }
        val audioRef = scenes.firstOrNull { it.pcm != null }?.pcm

        // ---- Video encoder ----
        val videoFormat = MediaFormat.createVideoFormat(
            MediaFormat.MIMETYPE_VIDEO_AVC, config.width, config.height
        ).apply {
            setInteger(
                MediaFormat.KEY_COLOR_FORMAT,
                MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420SemiPlanar
            )
            setInteger(MediaFormat.KEY_BIT_RATE, config.videoBitrate)
            setInteger(MediaFormat.KEY_FRAME_RATE, config.fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        }
        val videoEncoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        videoEncoder.configure(videoFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        videoEncoder.start()

        // ---- Audio encoder ----
        var audioEncoder: MediaCodec? = null
        if (hasAudio && audioRef != null) {
            val audioFormat = MediaFormat.createAudioFormat(
                MediaFormat.MIMETYPE_AUDIO_AAC, audioRef.sampleRate, audioRef.channels
            ).apply {
                setInteger(MediaFormat.KEY_BIT_RATE, config.audioBitrate)
                setInteger(
                    MediaFormat.KEY_AAC_PROFILE,
                    MediaCodecInfo.CodecCapabilities.AACObjectLC
                )
            }
            audioEncoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
            audioEncoder.configure(audioFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            audioEncoder.start()
        }

        val muxer = MediaMuxer(
            config.outputFile.absolutePath,
            MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4
        )
        val session = MuxSession(muxer, hasAudio)

        val frameBitmap = Bitmap.createBitmap(config.width, config.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(frameBitmap)
        val pixels = IntArray(config.width * config.height)
        val yuv = ByteArray(config.width * config.height * 3 / 2)

        val totalFrames = scenes.sumOf { ((it.durationMs * config.fps) / 1000).toInt().coerceAtLeast(1) }
        var encodedFrames = 0L
        var sceneStartUs = 0L

        try {
            for (scene in scenes) {
                val numFrames = ((scene.durationMs * config.fps) / 1000).toInt().coerceAtLeast(1)

                // ---- Video frames for this scene ----
                for (i in 0 until numFrames) {
                    val progress = if (numFrames == 1) 0f else i.toFloat() / (numFrames - 1)
                    drawFrame(canvas, scene, progress, config)
                    frameBitmap.getPixels(pixels, 0, config.width, 0, 0, config.width, config.height)
                    YuvConverter.argbToNv12(pixels, config.width, config.height, yuv)
                    val ptsUs = sceneStartUs + i * 1_000_000L / config.fps
                    feedVideoFrame(videoEncoder, yuv, ptsUs)
                    drain(videoEncoder, session, isAudio = false)
                    encodedFrames++
                    if (encodedFrames % 12L == 0L) {
                        onProgress((encodedFrames.toFloat() / totalFrames) * 0.9f)
                    }
                }

                // ---- Scene voiceover -> AAC ----
                val pcm = scene.pcm
                if (pcm != null && audioEncoder != null) {
                    feedAudio(audioEncoder, session, pcm, sceneStartUs)
                }

                sceneStartUs += numFrames * 1_000_000L / config.fps
            }

            // ---- End of stream ----
            signalEos(videoEncoder, sceneStartUs)
            drain(videoEncoder, session, isAudio = false)
            if (audioEncoder != null) {
                signalEos(audioEncoder, sceneStartUs)
                drain(audioEncoder, session, isAudio = true)
            }
            onProgress(0.97f)
        } finally {
            try {
                videoEncoder.stop()
                videoEncoder.release()
            } catch (_: Exception) {
            }
            try {
                audioEncoder?.stop()
                audioEncoder?.release()
            } catch (_: Exception) {
            }
            try {
                if (session.started) muxer.stop()
                muxer.release()
            } catch (_: Exception) {
            }
            if (!frameBitmap.isRecycled) frameBitmap.recycle()
        }
        onProgress(1f)
    }

    // ------------------------------------------------------------------
    // Frame drawing
    // ------------------------------------------------------------------

    private val bitmapPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val subtitlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
    }
    private val subtitleBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(160, 0, 0, 0)
    }

    private fun drawFrame(
        canvas: Canvas,
        scene: RenderScene,
        progress: Float,
        config: RenderConfig
    ) {
        canvas.drawColor(Color.BLACK)
        val matrix = KenBurns.computeMatrix(
            scene.motion, progress,
            scene.bitmap.width, scene.bitmap.height,
            config.width, config.height
        )
        canvas.drawBitmap(scene.bitmap, matrix, bitmapPaint)

        if (config.subtitlesEnabled && !scene.subtitle.isNullOrBlank()) {
            drawSubtitle(canvas, scene.subtitle, config)
        }
    }

    private fun drawSubtitle(canvas: Canvas, text: String, config: RenderConfig) {
        val textSizePx = config.subtitleSp * config.density
        subtitlePaint.textSize = textSizePx
        val maxWidth = config.width * 0.88f

        // Word wrap
        val words = text.split(Regex("\\s+"))
        val lines = mutableListOf<String>()
        var current = StringBuilder()
        for (w in words) {
            val trial = if (current.isEmpty()) w else "$current $w"
            if (subtitlePaint.measureText(trial) <= maxWidth) {
                if (current.isEmpty()) current.append(w) else current.append(" ").append(w)
            } else {
                if (current.isNotEmpty()) lines.add(current.toString())
                current = StringBuilder(w)
            }
        }
        if (current.isNotEmpty()) lines.add(current.toString())
        if (lines.isEmpty()) return

        val lineHeight = textSizePx * 1.25f
        val blockHeight = lineHeight * lines.size + textSizePx * 0.5f
        val margin = config.height * 0.06f
        val top = when (config.subtitlePosition) {
            SubtitlePosition.BOTTOM -> config.height - margin - blockHeight
            SubtitlePosition.TOP -> margin
        }

        val rect = RectF(
            config.width * 0.04f, top,
            config.width * 0.96f, top + blockHeight
        )
        canvas.drawRoundRect(rect, textSizePx * 0.35f, textSizePx * 0.35f, subtitleBgPaint)

        var y = top + textSizePx * 0.95f
        for (line in lines) {
            canvas.drawText(line, config.width / 2f, y, subtitlePaint)
            y += lineHeight
        }
    }

    // ------------------------------------------------------------------
    // Codec plumbing
    // ------------------------------------------------------------------

    private data class Sample(val data: ByteArray, val ptsUs: Long, val flags: Int)

    private inner class MuxSession(val muxer: MediaMuxer, val hasAudio: Boolean) {
        var videoTrack = -1
        var audioTrack = -1
        var started = false
        private val pendingVideo = ArrayDeque<Sample>()
        private val pendingAudio = ArrayDeque<Sample>()

        fun tryStart() {
            if (!started && videoTrack != -1 && (audioTrack != -1 || !hasAudio)) {
                muxer.start()
                started = true
                pendingVideo.forEach { writeSample(videoTrack, it) }
                pendingVideo.clear()
                pendingAudio.forEach { writeSample(audioTrack, it) }
                pendingAudio.clear()
            }
        }

        fun writeVideo(data: ByteArray, ptsUs: Long, flags: Int) {
            val s = Sample(data, ptsUs, flags)
            if (started) writeSample(videoTrack, s) else pendingVideo.add(s)
        }

        fun writeAudio(data: ByteArray, ptsUs: Long, flags: Int) {
            val s = Sample(data, ptsUs, flags)
            if (started) writeSample(audioTrack, s) else pendingAudio.add(s)
        }

        private fun writeSample(track: Int, s: Sample) {
            val info = MediaCodec.BufferInfo()
            info.set(s.data.size, 0, s.ptsUs, s.flags)
            muxer.writeSampleData(track, ByteBuffer.wrap(s.data), info)
        }
    }

    private fun drain(encoder: MediaCodec, session: MuxSession, isAudio: Boolean) {
        val info = MediaCodec.BufferInfo()
        while (true) {
            when (val idx = encoder.dequeueOutputBuffer(info, 10_000)) {
                MediaCodec.INFO_TRY_AGAIN_LATER -> return
                MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                    val format = encoder.outputFormat
                    if (isAudio) session.audioTrack = session.muxer.addTrack(format)
                    else session.videoTrack = session.muxer.addTrack(format)
                    session.tryStart()
                }
                else -> {
                    if (idx >= 0) {
                        val buf = encoder.getOutputBuffer(idx)
                        if (info.size > 0 && buf != null) {
                            val chunk = ByteArray(info.size)
                            buf.position(info.offset)
                            buf.limit(info.offset + info.size)
                            buf.get(chunk)
                            if (isAudio) session.writeAudio(chunk, info.presentationTimeUs, info.flags)
                            else session.writeVideo(chunk, info.presentationTimeUs, info.flags)
                        }
                        encoder.releaseOutputBuffer(idx, false)
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return
                    }
                }
            }
        }
    }

    private fun feedVideoFrame(encoder: MediaCodec, yuv: ByteArray, ptsUs: Long) {
        val idx = encoder.dequeueInputBuffer(10_000)
        if (idx >= 0) {
            val buf = encoder.getInputBuffer(idx)!!
            buf.clear()
            buf.put(yuv)
            encoder.queueInputBuffer(idx, 0, yuv.size, ptsUs, 0)
        }
    }

    private fun feedAudio(
        encoder: MediaCodec,
        session: MuxSession,
        pcm: PcmAudio,
        startUs: Long
    ) {
        val bytesPerSec = pcm.sampleRate.toLong() * pcm.channels * 2L
        var offset = 0
        val chunkSize = 4096
        while (offset < pcm.data.size) {
            val n = minOf(chunkSize, pcm.data.size - offset)
            val ptsUs = startUs + offset * 1_000_000L / bytesPerSec
            val idx = encoder.dequeueInputBuffer(10_000)
            if (idx >= 0) {
                val buf = encoder.getInputBuffer(idx)!!
                buf.clear()
                buf.put(pcm.data, offset, n)
                encoder.queueInputBuffer(idx, 0, n, ptsUs, 0)
            }
            offset += n
            drain(encoder, session, isAudio = true)
        }
    }

    private fun signalEos(encoder: MediaCodec, ptsUs: Long) {
        val idx = encoder.dequeueInputBuffer(10_000)
        if (idx >= 0) {
            encoder.queueInputBuffer(idx, 0, 0, ptsUs, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
        }
    }
}
