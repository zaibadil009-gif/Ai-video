package com.shahzaib.aivideostudio.ui.nav

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.shahzaib.aivideostudio.ui.screens.ExportScreen
import com.shahzaib.aivideostudio.ui.screens.HomeScreen
import com.shahzaib.aivideostudio.ui.screens.NewProjectScreen
import com.shahzaib.aivideostudio.ui.screens.ScriptScreen
import com.shahzaib.aivideostudio.ui.screens.SeoScreen
import com.shahzaib.aivideostudio.ui.screens.SettingsScreen
import com.shahzaib.aivideostudio.ui.screens.TimelineScreen
import com.shahzaib.aivideostudio.ui.studio.HomeViewModel
import com.shahzaib.aivideostudio.ui.studio.SettingsViewModel
import com.shahzaib.aivideostudio.ui.studio.StudioViewModel

@Composable
fun NavGraph(
    studioVm: StudioViewModel,
    homeVm: HomeViewModel,
    settingsVm: SettingsViewModel
) {
    val nav = rememberNavController()
    NavHost(navController = nav, startDestination = Routes.HOME) {
        composable(Routes.HOME) {
            HomeScreen(
                homeVm = homeVm,
                studioVm = studioVm,
                onNewProject = {
                    studioVm.resetForNew()
                    nav.navigate(Routes.NEW_PROJECT)
                },
                onOpenProject = { id ->
                    nav.navigate(Routes.TIMELINE)
                },
                onSettings = { nav.navigate(Routes.SETTINGS) }
            )
        }
        composable(Routes.NEW_PROJECT) {
            NewProjectScreen(
                vm = studioVm,
                onBack = { nav.popBackStack() },
                onScriptReady = { nav.navigate(Routes.SCRIPT) }
            )
        }
        composable(Routes.SCRIPT) {
            ScriptScreen(
                vm = studioVm,
                onBack = { nav.popBackStack() },
                onContinue = { nav.navigate(Routes.TIMELINE) }
            )
        }
        composable(Routes.TIMELINE) {
            TimelineScreen(
                vm = studioVm,
                onBack = { nav.popBackStack(Routes.HOME, inclusive = false) },
                onExport = { nav.navigate(Routes.EXPORT) }
            )
        }
        composable(Routes.EXPORT) {
            ExportScreen(
                vm = studioVm,
                settingsVm = settingsVm,
                onBack = { nav.popBackStack() },
                onSeo = { nav.navigate(Routes.SEO) }
            )
        }
        composable(Routes.SEO) {
            SeoScreen(
                vm = studioVm,
                onBack = { nav.popBackStack() },
                onDone = { nav.popBackStack(Routes.HOME, inclusive = false) }
            )
        }
        composable(Routes.SETTINGS) {
            SettingsScreen(
                vm = settingsVm,
                onBack = { nav.popBackStack() }
            )
        }
    }
}
