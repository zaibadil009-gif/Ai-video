package com.shahzaib.aivideostudio.script

import com.shahzaib.aivideostudio.data.model.MotionType
import com.shahzaib.aivideostudio.data.model.SceneDraft
import com.shahzaib.aivideostudio.data.model.ScriptDraft
import com.shahzaib.aivideostudio.data.prefs.SettingsRepository
import com.shahzaib.aivideostudio.network.LlmClient
import org.json.JSONObject

/**
 * Turns a bare topic or a pasted script into an editable [ScriptDraft].
 * Uses the user's own OpenAI-compatible key when configured, otherwise a
 * built-in template engine. The user can always paste/edit the full script.
 */
class ScriptEngine(
    private val llm: LlmClient,
    private val settings: SettingsRepository
) {
    private val motions = MotionType.values()

    suspend fun generate(topicOrScript: String, isScript: Boolean): ScriptDraft {
        val s = settings.snapshot()
        val input = topicOrScript.trim()
        require(input.isNotEmpty()) { "Please enter a topic or paste a script first." }

        if (s.hasLlmKey) {
            return try {
                val raw = llm.chat(
                    baseUrl = s.llmBaseUrl,
                    apiKey = s.llmApiKey,
                    model = s.llmModel,
                    system = "You are a scriptwriter for English-language documentary, personal-finance " +
                        "and history YouTube videos. You ALWAYS reply with strict JSON only, no markdown, " +
                        "no commentary. Schema: {\"title\": string, \"scenes\": [{\"imagePrompt\": string, " +
                        "\"narration\": string}]}. imagePrompt is a vivid, cinematic, photorealistic image " +
                        "description for that scene (no text in image). narration is the spoken English " +
                        "voiceover for that scene, 25-40 words, plain spoken language.",
                    user = if (isScript) {
                        "Split the following script into 4-8 scenes and return the JSON. " +
                            "Keep narration faithful to the script. Script:\n\n$input"
                    } else {
                        "The video topic is: \"$input\". Create a compelling 5-scene video outline and " +
                            "return the JSON with a catchy title."
                    }
                )
                parseJson(llm.cleanJson(raw))
            } catch (e: Exception) {
                // Fall back to the offline template engine so the user is never blocked.
                templateDraft(input, isScript)
            }
        }
        return templateDraft(input, isScript)
    }

    private fun parseJson(json: String): ScriptDraft {
        val root = JSONObject(json)
        val title = root.optString("title", "Untitled Video").take(120)
        val arr = root.getJSONArray("scenes")
        val scenes = (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            SceneDraft(
                order = i,
                imagePrompt = o.optString("imagePrompt", "Cinematic documentary film still"),
                narration = o.optString("narration", ""),
                motion = motions[i % motions.size]
            )
        }
        require(scenes.isNotEmpty()) { "The AI returned no scenes." }
        return ScriptDraft(title = title, scenes = scenes)
    }

    /**
     * Offline engine:
     * - pasted script  -> split into scenes by paragraph
     * - bare topic     -> 5-scene documentary structure with editable placeholders
     */
    private fun templateDraft(input: String, isScript: Boolean): ScriptDraft {
        if (isScript) {
            val paras = input.split(Regex("\\n\\s*\\n")).map { it.trim().filterNot { c -> c == '\r' } }
                .filter { it.isNotEmpty() }
            val chunks = if (paras.size > 1) paras else input.split("\n").map { it.trim() }.filter { it.isNotEmpty() }
            val title = chunks.first().take(70).trim()
            val scenes = chunks.mapIndexed { i, para ->
                SceneDraft(
                    order = i,
                    imagePrompt = "Cinematic documentary film still, photorealistic, dramatic lighting: " +
                        para.split(" ").take(14).joinToString(" "),
                    narration = para,
                    motion = motions[i % motions.size]
                )
            }
            return ScriptDraft(title = title.ifBlank { "Untitled Video" }, scenes = scenes)
        }

        val topic = input
        val beats = listOf(
            "Hook" to "Open with a bold claim or surprising question about $topic that stops the scroll. " +
                "[Edit me: write your 2-sentence hook here.]",
            "Context" to "Set the stage: what is $topic, and why does it matter right now? " +
                "[Edit me: add the background your viewer needs.]",
            "Deep dive" to "Explain the key facts, numbers and turning points behind $topic in simple English. " +
                "[Edit me: add your research points here.]",
            "Story" to "Tell a real human story or example that makes $topic unforgettable. " +
                "[Edit me: add the story or case study.]",
            "Takeaway" to "Close with the one lesson about $topic the viewer should remember, plus a call to action. " +
                "[Edit me: write your closing lines.]"
        )
        val scenes = beats.mapIndexed { i, (beat, narration) ->
            SceneDraft(
                order = i,
                imagePrompt = "Cinematic documentary film still, photorealistic, dramatic lighting, " +
                    "representing $topic, scene: $beat, no text",
                narration = narration,
                motion = motions[i % motions.size]
            )
        }
        return ScriptDraft(title = topic.take(70), scenes = scenes)
    }
}
