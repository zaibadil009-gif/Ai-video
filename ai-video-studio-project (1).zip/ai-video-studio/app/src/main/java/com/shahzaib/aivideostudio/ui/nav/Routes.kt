package com.shahzaib.aivideostudio.ui.nav

/** Navigation destinations. */
object Routes {
    const val HOME = "home"
    const val NEW_PROJECT = "new_project"
    const val SCRIPT = "script"
    const val TIMELINE = "timeline"
    const val EXPORT = "export"
    const val SEO = "seo"
    const val SETTINGS = "settings"
}
