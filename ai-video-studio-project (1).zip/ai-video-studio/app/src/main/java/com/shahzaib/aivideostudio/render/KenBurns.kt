package com.shahzaib.aivideostudio.render

import android.graphics.Matrix
import com.shahzaib.aivideostudio.data.model.MotionType
import kotlin.math.max

/**
 * Computes the per-frame draw [Matrix] that maps a source bitmap onto the
 * export frame with a Ken Burns style motion. [progress] runs 0..1 across
 * the scene's frames.
 */
object KenBurns {

    fun computeMatrix(
        motion: MotionType,
        progress: Float,
        srcW: Int,
        srcH: Int,
        dstW: Int,
        dstH: Int
    ): Matrix {
        val p = progress.coerceIn(0f, 1f)
        val cover = max(dstW.toFloat() / srcW, dstH.toFloat() / srcH)
        val m = Matrix()
        when (motion) {
            MotionType.ZOOM_IN -> {
                val s = cover * (1f + 0.18f * p)
                m.setScale(s, s)
                m.postTranslate((dstW - srcW * s) / 2f, (dstH - srcH * s) / 2f)
            }
            MotionType.ZOOM_OUT -> {
                val s = cover * (1.18f - 0.18f * p)
                m.setScale(s, s)
                m.postTranslate((dstW - srcW * s) / 2f, (dstH - srcH * s) / 2f)
            }
            MotionType.PAN_LEFT -> {
                val s = cover * 1.18f
                val overflowX = (srcW * s - dstW).coerceAtLeast(0f)
                m.setScale(s, s)
                m.postTranslate(-overflowX * p, (dstH - srcH * s) / 2f)
            }
            MotionType.PAN_RIGHT -> {
                val s = cover * 1.18f
                val overflowX = (srcW * s - dstW).coerceAtLeast(0f)
                m.setScale(s, s)
                m.postTranslate(-overflowX * (1f - p), (dstH - srcH * s) / 2f)
            }
            MotionType.STATIC -> {
                m.setScale(cover, cover)
                m.postTranslate((dstW - srcW * cover) / 2f, (dstH - srcH * cover) / 2f)
            }
        }
        return m
    }
}
