package com.shahzaib.aivideostudio.render

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader

/** Fallback artwork for scenes that have no image yet (never a blank video). */
object PlaceholderArt {

    fun make(sceneIndex: Int, title: String, width: Int, height: Int): Bitmap {
        val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val bg = Paint().apply {
            shader = LinearGradient(
                0f, 0f, width.toFloat(), height.toFloat(),
                Color.parseColor("#1A1A2E"), Color.parseColor("#16213E"),
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bg)

        val accent = Paint().apply {
            color = Color.parseColor("#7C4DFF")
            alpha = 90
        }
        val r = minOf(width, height) * 0.32f
        canvas.drawCircle(width / 2f, height * 0.42f, r, accent)

        val play = Paint().apply { color = Color.WHITE; alpha = 220 }
        val cx = width / 2f
        val cy = height * 0.42f
        val s = r * 0.45f
        val path = android.graphics.Path().apply {
            moveTo(cx - s * 0.6f, cy - s)
            lineTo(cx + s * 0.8f, cy)
            lineTo(cx - s * 0.6f, cy + s)
            close()
        }
        canvas.drawPath(path, play)

        val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textAlign = Paint.Align.CENTER
            textSize = width * 0.055f
        }
        canvas.drawText("Scene ${sceneIndex + 1}", width / 2f, height * 0.62f, text)
        val sub = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(200, 255, 255, 255)
            textAlign = Paint.Align.CENTER
            textSize = width * 0.04f
        }
        val short = title.take(34)
        if (short.isNotBlank()) canvas.drawText(short, width / 2f, height * 0.62f + width * 0.07f, sub)
        return bmp
    }
}
