package com.shahzaib.aivideostudio.tts

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import com.shahzaib.aivideostudio.data.model.TtsLocale
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.File
import java.util.Locale
import java.util.UUID
import kotlin.coroutines.resume

/**
 * Free, on-device voiceover using Android's built-in TextToSpeech engine.
 * Audio is rendered with [synthesizeToFile] into WAV files, one per scene.
 */
class TtsManager(private val context: Context) {

    private var tts: TextToSpeech? = null
    private var currentLocale: Locale? = null
    private var initJob: kotlinx.coroutines.Job? = null

    private fun localeFor(tag: TtsLocale): Locale = when (tag) {
        TtsLocale.US -> Locale.US
        TtsLocale.UK -> Locale.UK
    }

    /**
     * Ensures the engine is initialized for the requested locale.
     * Returns false if the engine or language data is unavailable.
     */
    suspend fun ensureInit(localeTag: TtsLocale): Boolean {
        val want = localeFor(localeTag)
        val existing = tts
        if (existing != null && currentLocale == want) return true
        shutdown()

        return suspendCancellableCoroutine { cont ->
            var engine: TextToSpeech? = null
            engine = TextToSpeech(context.applicationContext) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    val langStatus = engine?.setLanguage(want) ?: TextToSpeech.LANG_MISSING_DATA
                    if (langStatus == TextToSpeech.LANG_MISSING_DATA ||
                        langStatus == TextToSpeech.LANG_NOT_SUPPORTED
                    ) {
                        cont.resume(false)
                    } else {
                        tts = engine
                        currentLocale = want
                        cont.resume(true)
                    }
                } else {
                    cont.resume(false)
                }
            }
            cont.invokeOnCancellation { engine?.shutdown() }
        }
    }

    fun applyVoiceSettings(pitch: Float, rate: Float, voiceName: String?) {
        val engine = tts ?: return
        engine.setPitch(pitch.coerceIn(0.5f, 2.0f))
        engine.setSpeechRate(rate.coerceIn(0.5f, 2.0f))
        if (!voiceName.isNullOrBlank()) {
            engine.voices?.firstOrNull { it.name == voiceName }?.let { engine.voice = it }
        }
    }

    /** English voices installed on this device (for the settings picker). */
    fun englishVoices(): List<Voice> =
        tts?.voices?.filter { it.locale.language == "en" }?.sortedBy { it.name } ?: emptyList()

    /** Renders [text] to a WAV file. Throws on failure. */
    suspend fun synthesizeToFile(
        text: String,
        outFile: File,
        localeTag: TtsLocale,
        pitch: Float,
        rate: Float,
        voiceName: String?
    ): File {
        if (!ensureInit(localeTag)) throw IllegalStateException("Text-to-speech engine unavailable")
        applyVoiceSettings(pitch, rate, voiceName)
        val engine = tts ?: throw IllegalStateException("Text-to-speech engine unavailable")
        outFile.parentFile?.mkdirs()

        return suspendCancellableCoroutine { cont ->
            val utteranceId = UUID.randomUUID().toString()
            engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String) = Unit
                override fun onError(id: String) {
                    if (!cont.isCompleted) cont.resumeWith(Result.failure(IllegalStateException("TTS synthesis failed")))
                }

                @Deprecated("Deprecated in Java")
                override fun onError(id: String, errorCode: Int) = onError(id)

                override fun onDone(id: String) {
                    if (!cont.isCompleted) {
                        if (outFile.exists() && outFile.length() > 0) cont.resume(outFile)
                        else cont.resumeWith(Result.failure(IllegalStateException("TTS produced no audio")))
                    }
                }
            })
            val params = Bundle()
            val rc = engine.synthesizeToFile(text, params, outFile, utteranceId)
            if (rc == TextToSpeech.ERROR) {
                cont.resumeWith(Result.failure(IllegalStateException("TTS rejected the request")))
            }
            cont.invokeOnCancellation { engine.stop() }
        }
    }

    /** Quick spoken preview (not saved). */
    fun speak(text: String, localeTag: TtsLocale, pitch: Float, rate: Float) {
        val engine = tts ?: return
        if (currentLocale != localeFor(localeTag)) return
        engine.setPitch(pitch.coerceIn(0.5f, 2.0f))
        engine.setSpeechRate(rate.coerceIn(0.5f, 2.0f))
        engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, UUID.randomUUID().toString())
    }

    fun stop() {
        tts?.stop()
    }

    fun shutdown() {
        initJob?.cancel()
        tts?.shutdown()
        tts = null
        currentLocale = null
    }
}
