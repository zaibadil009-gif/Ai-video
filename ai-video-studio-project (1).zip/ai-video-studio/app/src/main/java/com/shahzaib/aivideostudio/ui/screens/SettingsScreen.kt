package com.shahzaib.aivideostudio.ui.screens

import android.speech.tts.Voice
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.shahzaib.aivideostudio.data.model.AspectRatio
import com.shahzaib.aivideostudio.data.model.ExportResolution
import com.shahzaib.aivideostudio.data.model.TtsLocale
import com.shahzaib.aivideostudio.ui.components.ChipRow
import com.shahzaib.aivideostudio.ui.components.FullWidthButton
import com.shahzaib.aivideostudio.ui.components.LabeledSlider
import com.shahzaib.aivideostudio.ui.components.SectionTitle
import com.shahzaib.aivideostudio.ui.components.SpacerH
import com.shahzaib.aivideostudio.ui.components.StudioScaffold
import com.shahzaib.aivideostudio.ui.studio.SettingsViewModel

/** App settings: optional LLM key, TTS voice, export quality, subtitles. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    vm: SettingsViewModel,
    onBack: () -> Unit
) {
    val settings by vm.settings.collectAsState()

    var baseUrl by remember(settings.llmBaseUrl) { mutableStateOf(settings.llmBaseUrl) }
    var apiKey by remember(settings.llmApiKey) { mutableStateOf(settings.llmApiKey) }
    var model by remember(settings.llmModel) { mutableStateOf(settings.llmModel) }
    var voices by remember { mutableStateOf<List<Voice>>(emptyList()) }
    var voicesLoading by remember { mutableStateOf(false) }
    var voiceMenuOpen by remember { mutableStateOf(false) }

    StudioScaffold(title = "Settings", onBack = onBack, error = null, onErrorConsumed = {}) { modifier ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            SectionTitle("AI script writer (optional)")
            Text(
                "Add your own OpenAI-compatible key for smarter scripts & SEO. " +
                    "Works with OpenAI, OpenRouter, Groq, Together, LM Studio, Ollama… " +
                    "Leave empty to use the free built-in writer.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            OutlinedTextField(
                value = baseUrl,
                onValueChange = { baseUrl = it },
                label = { Text("Base URL") },
                placeholder = { Text("https://api.openai.com/v1") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            OutlinedTextField(
                value = apiKey,
                onValueChange = { apiKey = it },
                label = { Text("API key") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                visualTransformation = PasswordVisualTransformation()
            )
            OutlinedTextField(
                value = model,
                onValueChange = { model = it },
                label = { Text("Model") },
                placeholder = { Text("gpt-4o-mini") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            FullWidthButton(
                text = "Save AI settings",
                outlined = true,
                onClick = { vm.saveLlm(baseUrl, apiKey, model) }
            )

            SpacerH(8)
            SectionTitle("Voiceover")
            Text(
                "Voice is generated free on your phone — no key, no cost.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            ChipRow(
                options = TtsLocale.values().map { it.label },
                selected = settings.ttsLocale.label,
                onSelect = { label ->
                    val locale = TtsLocale.values().first { it.label == label }
                    vm.saveTts(locale, settings.ttsPitch, settings.ttsRate, settings.ttsVoiceName)
                }
            )
            LabeledSlider(
                label = "Pitch",
                value = settings.ttsPitch,
                range = 0.5f..2.0f,
                onChange = {
                    vm.saveTts(settings.ttsLocale, it, settings.ttsRate, settings.ttsVoiceName)
                }
            )
            LabeledSlider(
                label = "Speed",
                value = settings.ttsRate,
                range = 0.5f..2.0f,
                onChange = {
                    vm.saveTts(settings.ttsLocale, settings.ttsPitch, it, settings.ttsVoiceName)
                }
            )
            FullWidthButton(
                text = if (voicesLoading) "Loading voices…" else "Load device voices",
                outlined = true,
                enabled = !voicesLoading,
                onClick = {
                    voicesLoading = true
                    vm.refreshVoices {
                        voices = it
                        voicesLoading = false
                        voiceMenuOpen = true
                    }
                }
            )
            if (voices.isNotEmpty()) {
                ExposedDropdownMenuBox(
                    expanded = voiceMenuOpen,
                    onExpandedChange = { voiceMenuOpen = it }
                ) {
                    OutlinedTextField(
                        value = settings.ttsVoiceName.ifBlank { "Default voice" },
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Voice") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(voiceMenuOpen) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor()
                    )
                    ExposedDropdownMenu(
                        expanded = voiceMenuOpen,
                        onDismissRequest = { voiceMenuOpen = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("Default voice") },
                            onClick = {
                                vm.saveTts(settings.ttsLocale, settings.ttsPitch, settings.ttsRate, "")
                                voiceMenuOpen = false
                            }
                        )
                        voices.forEach { voice ->
                            DropdownMenuItem(
                                text = { Text(voice.name.take(60)) },
                                onClick = {
                                    vm.saveTts(
                                        settings.ttsLocale, settings.ttsPitch,
                                        settings.ttsRate, voice.name
                                    )
                                    voiceMenuOpen = false
                                }
                            )
                        }
                    }
                }
            }

            SpacerH(8)
            SectionTitle("Export")
            Text("Resolution", style = MaterialTheme.typography.labelLarge)
            ChipRow(
                options = ExportResolution.values().map { it.label },
                selected = settings.exportResolution.label,
                onSelect = { label ->
                    vm.saveExport(
                        ExportResolution.values().first { it.label == label },
                        settings.aspect
                    )
                }
            )
            SpacerH(4)
            Text("Shape", style = MaterialTheme.typography.labelLarge)
            ChipRow(
                options = AspectRatio.values().map { it.label },
                selected = settings.aspect.label,
                onSelect = { label ->
                    vm.saveExport(
                        settings.exportResolution,
                        AspectRatio.values().first { it.label == label }
                    )
                }
            )
            SpacerH(16)
        }
    }
}
