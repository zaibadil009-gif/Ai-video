package com.shahzaib.aivideostudio.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import com.shahzaib.aivideostudio.ui.components.FullWidthButton
import com.shahzaib.aivideostudio.ui.components.SectionTitle
import com.shahzaib.aivideostudio.ui.components.SpacerH
import com.shahzaib.aivideostudio.ui.components.StudioScaffold
import com.shahzaib.aivideostudio.ui.studio.StudioViewModel

/** Step 5: upload SEO package + voiceover-only export. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SeoScreen(
    vm: StudioViewModel,
    onBack: () -> Unit,
    onDone: () -> Unit
) {
    val clipboard = LocalClipboardManager.current
    val context = LocalContext.current

    LaunchedEffect(Unit) {
        if (vm.seo == null) vm.generateSeo()
    }

    StudioScaffold(
        title = "Upload SEO",
        onBack = onBack,
        busyMessage = vm.busyMessage,
        error = vm.error,
        onErrorConsumed = { vm.error = null }
    ) { modifier ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val seo = vm.seo
            if (seo == null) {
                Text(
                    "Writing your upload package…",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                SeoCard(
                    title = "Title",
                    body = seo.title,
                    onCopy = { clipboard.setText(AnnotatedString(seo.title)) }
                )
                SeoCard(
                    title = "Description",
                    body = seo.description,
                    onCopy = { clipboard.setText(AnnotatedString(seo.description)) }
                )
                SectionTitle("Tags")
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    seo.tags.forEach { tag ->
                        AssistChip(onClick = { clipboard.setText(AnnotatedString(tag)) }, label = { Text(tag) })
                    }
                }
                FullWidthButton(
                    text = "Copy all tags",
                    outlined = true,
                    onClick = { clipboard.setText(AnnotatedString(seo.tags.joinToString(", "))) }
                )
                SectionTitle("Hashtags")
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    seo.hashtags.forEach { tag ->
                        AssistChip(onClick = { clipboard.setText(AnnotatedString(tag)) }, label = { Text(tag) })
                    }
                }
                FullWidthButton(
                    text = "Copy all hashtags",
                    outlined = true,
                    onClick = { clipboard.setText(AnnotatedString(seo.hashtags.joinToString(" "))) }
                )
            }

            SpacerH(8)
            SectionTitle("Voiceover only")
            Text(
                "Need just the narration audio (e.g. to edit in CapCut)? " +
                    "This merges every scene's voiceover into one file.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            FullWidthButton(
                text = "Export voiceover only",
                outlined = true,
                enabled = vm.busyMessage == null,
                onClick = { vm.exportVoiceoverOnly(context) }
            )
            SpacerH(8)
            FullWidthButton(text = "Done — back to projects", onClick = onDone)
        }
    }
}

@Composable
private fun SeoCard(title: String, body: String, onCopy: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(title, style = MaterialTheme.typography.titleMedium)
                IconButton(onClick = onCopy) {
                    Icon(Icons.Default.ContentCopy, contentDescription = "Copy $title")
                }
            }
            Text(body, style = MaterialTheme.typography.bodyMedium)
        }
    }
}
