package com.shahzaib.aivideostudio.audio

import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Decoded PCM audio from a WAV file. */
data class PcmAudio(
    val data: ByteArray,
    val sampleRate: Int,
    val channels: Int
) {
    val durationMs: Long
        get() = if (sampleRate > 0 && channels > 0)
            (data.size * 1000L) / (sampleRate * channels * 2L) else 0L
}

/** Minimal WAV (RIFF PCM) reader/writer used for TTS output. */
object WavUtils {

    /** Reads a 16-bit PCM WAV file produced by Android TTS. */
    fun readWav(file: File): PcmAudio {
        RandomAccessFile(file, "r").use { raf ->
            val header = ByteArray(64)
            raf.readFully(header)
            val buf = ByteBuffer.wrap(header).order(ByteOrder.LITTLE_ENDIAN)
            require(buf.getInt(0) == 0x46464952) { "Not a RIFF file" } // "RIFF"

            // fmt chunk (assumed at offset 12 for TTS output, but scan robustly)
            var fmtRate = 0
            var fmtChannels = 0
            var fmtBits = 0
            var dataOffset = -1
            var dataSize = 0
            var pos = 12
            val fileLen = raf.length()
            while (pos + 8 <= fileLen) {
                raf.seek(pos.toLong())
                val chunkId = ByteArray(4).also { raf.readFully(it) }
                val chunkSize = Integer.reverseBytes(raf.readInt())
                val id = String(chunkId, Charsets.US_ASCII)
                when (id) {
                    "fmt " -> {
                        val fmt = ByteArray(minOf(chunkSize, 40)).also { raf.readFully(it) }
                        val fb = ByteBuffer.wrap(fmt).order(ByteOrder.LITTLE_ENDIAN)
                        val audioFormat = fb.getShort(0).toInt()
                        require(audioFormat == 1) { "Only PCM WAV supported (format=$audioFormat)" }
                        fmtChannels = fb.getShort(2).toInt()
                        fmtRate = fb.getInt(4)
                        fmtBits = fb.getShort(14).toInt()
                    }
                    "data" -> {
                        dataOffset = pos + 8
                        dataSize = chunkSize
                    }
                }
                pos += 8 + chunkSize + (chunkSize and 1)
                if (dataOffset != -1 && fmtRate != 0) break
            }
            require(dataOffset != -1) { "WAV data chunk not found" }
            require(fmtBits == 16) { "Only 16-bit WAV supported (bits=$fmtBits)" }
            raf.seek(dataOffset.toLong())
            val data = ByteArray(dataSize)
            var read = 0
            while (read < dataSize) {
                val n = raf.read(data, read, dataSize - read)
                if (n < 0) break
                read += n
            }
            return PcmAudio(data.copyOf(read), fmtRate, fmtChannels)
        }
    }

    fun durationMs(file: File): Long = try {
        readWav(file).durationMs
    } catch (_: Exception) {
        0L
    }

    /** Concatenates same-format WAV files into one (for "voiceover only" export). */
    fun concatWavs(inputs: List<File>, out: File) {
        require(inputs.isNotEmpty())
        val decoded = inputs.map { readWav(it) }
        val first = decoded.first()
        decoded.forEach {
            require(it.sampleRate == first.sampleRate && it.channels == first.channels) {
                "All voiceovers must share the same audio format"
            }
        }
        val total = decoded.sumOf { it.data.size }
        out.parentFile?.mkdirs()
        out.outputStream().use { os ->
            writeHeader(os, total, first.sampleRate, first.channels)
            decoded.forEach { os.write(it.data) }
        }
    }

    /** Writes a WAV file from raw 16-bit PCM. */
    fun writeWav(pcm: PcmAudio, out: File) {
        out.parentFile?.mkdirs()
        out.outputStream().use { os ->
            writeHeader(os, pcm.data.size, pcm.sampleRate, pcm.channels)
            os.write(pcm.data)
        }
    }

    private fun writeHeader(os: java.io.OutputStream, dataSize: Int, sampleRate: Int, channels: Int) {
        val buf = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        buf.put("RIFF".toByteArray(Charsets.US_ASCII))
        buf.putInt(36 + dataSize)
        buf.put("WAVE".toByteArray(Charsets.US_ASCII))
        buf.put("fmt ".toByteArray(Charsets.US_ASCII))
        buf.putInt(16)
        buf.putShort(1) // PCM
        buf.putShort(channels.toShort())
        buf.putInt(sampleRate)
        buf.putInt(sampleRate * channels * 2)
        buf.putShort((channels * 2).toShort()) // block align
        buf.putShort(16) // bits per sample
        buf.put("data".toByteArray(Charsets.US_ASCII))
        buf.putInt(dataSize)
        os.write(buf.array())
    }
}
